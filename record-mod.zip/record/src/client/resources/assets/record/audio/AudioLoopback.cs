// Records everything that plays on the default Windows output device (WASAPI loopback)
// into a raw PCM file, so the Record mod can add the game's sound to the video.
//
//   AudioLoopback.exe <out.pcm> <out.fmt>
//
// It prints "started" once it is capturing (or "error: <reason>" and exits), and stops when it
// reads a line "stop" on stdin (or when stdin is closed, e.g. the game exited).
// Written in C# 5 so the compiler that ships with every Windows (csc.exe, .NET Framework 4) can build it.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public static class AudioLoopback
{
    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    class MMDeviceEnumeratorCom { }

    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDeviceEnumerator
    {
        [PreserveSig] int EnumAudioEndpoints(int dataFlow, int stateMask, out IntPtr devices);
        [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice endpoint);
    }

    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDevice
    {
        [PreserveSig] int Activate(ref Guid iid, int clsCtx, IntPtr activationParams,
            [MarshalAs(UnmanagedType.IUnknown)] out object interfacePointer);
    }

    [ComImport, Guid("1CB9AD4C-DBFA-4c32-B178-C2F568A703B2"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAudioClient
    {
        [PreserveSig] int Initialize(int shareMode, int streamFlags, long hnsBufferDuration, long hnsPeriodicity,
            IntPtr pFormat, IntPtr audioSessionGuid);
        [PreserveSig] int GetBufferSize(out uint bufferFrameCount);
        [PreserveSig] int GetStreamLatency(out long hnsLatency);
        [PreserveSig] int GetCurrentPadding(out uint numPaddingFrames);
        [PreserveSig] int IsFormatSupported(int shareMode, IntPtr pFormat, out IntPtr closestMatch);
        [PreserveSig] int GetMixFormat(out IntPtr deviceFormatPointer);
        [PreserveSig] int GetDevicePeriod(out long hnsDefaultDevicePeriod, out long hnsMinimumDevicePeriod);
        [PreserveSig] int Start();
        [PreserveSig] int Stop();
        [PreserveSig] int Reset();
        [PreserveSig] int SetEventHandle(IntPtr eventHandle);
        [PreserveSig] int GetService(ref Guid interfaceId, [MarshalAs(UnmanagedType.IUnknown)] out object interfacePointer);
    }

    [ComImport, Guid("C8ADBD64-E71E-48a0-A4DE-185C395CD317"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAudioCaptureClient
    {
        [PreserveSig] int GetBuffer(out IntPtr dataBuffer, out int numFramesToRead, out int bufferFlags,
            out long devicePosition, out long qpcPosition);
        [PreserveSig] int ReleaseBuffer(int numFramesRead);
        [PreserveSig] int GetNextPacketSize(out int numFramesInNextPacket);
    }

    [DllImport("kernel32.dll")] static extern bool QueryPerformanceCounter(out long value);
    [DllImport("kernel32.dll")] static extern bool QueryPerformanceFrequency(out long value);

    const int AUDCLNT_STREAMFLAGS_LOOPBACK = 0x00020000;
    const int AUDCLNT_BUFFERFLAGS_SILENT = 0x2;
    const int AUDCLNT_BUFFERFLAGS_TIMESTAMP_ERROR = 0x4;

    static volatile bool stopRequested;

    public static int Main(string[] args)
    {
        if (args.Length < 2)
        {
            Console.WriteLine("error: usage: AudioLoopback <out.pcm> <out.fmt>");
            return 2;
        }
        try
        {
            return Run(args[0], args[1]);
        }
        catch (Exception e)
        {
            Console.WriteLine("error: " + e.Message.Replace('\n', ' ').Replace('\r', ' '));
            return 1;
        }
    }

    static void Check(int hr, string what)
    {
        if (hr < 0)
        {
            throw new Exception(what + " failed (0x" + hr.ToString("X8") + ")");
        }
    }

    /// <summary>
    /// WASAPI loopback delivers nothing while the PC is silent. This returns how many silent frames must be
    /// inserted before a packet that starts at qpc100ns, so the audio keeps the real timeline.
    /// </summary>
    public static long GapFrames(long start100ns, long qpc100ns, int rate, long framesWritten)
    {
        long expected = (qpc100ns - start100ns) * rate / 10000000L;
        if (expected < 0) expected = 0;
        long gap = expected - framesWritten;
        return gap > rate / 100 ? gap : 0;   // ignore anything under 10 ms
    }

    static long To100ns(long counter, long freq)
    {
        return (counter / freq) * 10000000L + ((counter % freq) * 10000000L) / freq;
    }

    static void WriteSilence(Stream output, long frames, int frameBytes)
    {
        byte[] zeros = new byte[65536 - (65536 % frameBytes)];
        long remaining = frames * frameBytes;
        while (remaining > 0)
        {
            int n = (int)Math.Min(remaining, (long)zeros.Length);
            output.Write(zeros, 0, n);
            remaining -= n;
        }
    }

    static int Run(string pcmPath, string fmtPath)
    {
        Thread reader = new Thread(delegate()
        {
            try
            {
                string line;
                while ((line = Console.In.ReadLine()) != null)
                {
                    if (line.Trim().ToLowerInvariant() == "stop") break;
                }
            }
            catch (Exception) { }
            stopRequested = true;
        });
        reader.IsBackground = true;
        reader.Start();

        IMMDeviceEnumerator enumerator = (IMMDeviceEnumerator)new MMDeviceEnumeratorCom();
        IMMDevice device;
        Check(enumerator.GetDefaultAudioEndpoint(0, 0, out device), "find the default output device");

        Guid iidClient = new Guid("1CB9AD4C-DBFA-4c32-B178-C2F568A703B2");
        object clientObj;
        Check(device.Activate(ref iidClient, 23, IntPtr.Zero, out clientObj), "open the output device");
        IAudioClient client = (IAudioClient)clientObj;

        IntPtr fmt;
        Check(client.GetMixFormat(out fmt), "read the mix format");
        int tag = (ushort)Marshal.ReadInt16(fmt, 0);
        int channels = Marshal.ReadInt16(fmt, 2);
        int rate = Marshal.ReadInt32(fmt, 4);
        int blockAlign = Marshal.ReadInt16(fmt, 12);
        int bits = Marshal.ReadInt16(fmt, 14);
        bool isFloat = tag == 3;
        if (tag == 0xFFFE)
        {
            isFloat = Marshal.ReadInt32(fmt, 24) == 3;   // first 4 bytes of the SubFormat GUID
        }
        string format;
        if (isFloat) format = bits == 64 ? "f64le" : "f32le";
        else if (bits == 16) format = "s16le";
        else if (bits == 24) format = "s24le";
        else format = "s32le";

        Check(client.Initialize(0, AUDCLNT_STREAMFLAGS_LOOPBACK, 2000000L, 0L, fmt, IntPtr.Zero), "start loopback capture");
        Marshal.FreeCoTaskMem(fmt);

        Guid iidCapture = new Guid("C8ADBD64-E71E-48a0-A4DE-185C395CD317");
        object captureObj;
        Check(client.GetService(ref iidCapture, out captureObj), "get the capture service");
        IAudioCaptureClient capture = (IAudioCaptureClient)captureObj;

        long freq;
        QueryPerformanceFrequency(out freq);
        FileStream pcm = new FileStream(pcmPath, FileMode.Create, FileAccess.Write, FileShare.Read, 1 << 20);

        Check(client.Start(), "start the stream");
        long counter;
        QueryPerformanceCounter(out counter);
        long start100ns = To100ns(counter, freq);
        Stopwatch clock = Stopwatch.StartNew();
        long startEpochMs = (long)(DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds;

        File.WriteAllText(fmtPath,
            "format=" + format + "\nrate=" + rate + "\nchannels=" + channels + "\nstartEpochMs=" + startEpochMs + "\n",
            Encoding.ASCII);
        Console.WriteLine("started");
        Console.Out.Flush();

        long framesWritten = 0;
        byte[] chunk = new byte[1 << 16];
        while (!stopRequested)
        {
            Thread.Sleep(10);
            int packet;
            Check(capture.GetNextPacketSize(out packet), "read the packet size");
            while (packet != 0)
            {
                IntPtr data;
                int frames;
                int flags;
                long devicePos;
                long qpc;
                Check(capture.GetBuffer(out data, out frames, out flags, out devicePos, out qpc), "read audio");

                if ((flags & AUDCLNT_BUFFERFLAGS_TIMESTAMP_ERROR) == 0 && qpc != 0)
                {
                    long gap = GapFrames(start100ns, qpc, rate, framesWritten);
                    if (gap > 0)
                    {
                        WriteSilence(pcm, gap, blockAlign);
                        framesWritten += gap;
                    }
                }
                if ((flags & AUDCLNT_BUFFERFLAGS_SILENT) != 0)
                {
                    WriteSilence(pcm, frames, blockAlign);
                }
                else
                {
                    long total = (long)frames * blockAlign;
                    long offset = 0;
                    while (offset < total)
                    {
                        int n = (int)Math.Min(total - offset, (long)chunk.Length);
                        Marshal.Copy(new IntPtr(data.ToInt64() + offset), chunk, 0, n);
                        pcm.Write(chunk, 0, n);
                        offset += n;
                    }
                }
                framesWritten += frames;
                Check(capture.ReleaseBuffer(frames), "release the buffer");
                Check(capture.GetNextPacketSize(out packet), "read the packet size");
            }
        }

        // Keep the audio exactly as long as the recording, even if the last seconds were silent.
        long elapsedFrames = (long)(clock.Elapsed.TotalSeconds * rate);
        if (elapsedFrames > framesWritten)
        {
            WriteSilence(pcm, elapsedFrames - framesWritten, blockAlign);
            framesWritten = elapsedFrames;
        }
        client.Stop();
        pcm.Flush();
        pcm.Close();
        File.AppendAllText(fmtPath, "frames=" + framesWritten + "\n", Encoding.ASCII);
        return 0;
    }
}
