package com.sigmaxox.record.client.ffmpeg;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * A raw PCM audio recording that FFmpeg should add to a video.
 * offsetSec = when the audio starts relative to the start of the video (positive: audio starts later).
 */
public record AudioInput(Path pcm, String format, int rate, int channels, double offsetSec) {

	public AudioInput withOffset(double newOffsetSec) {
		return new AudioInput(pcm, format, rate, channels, newOffsetSec);
	}

	/** FFmpeg input options for this audio file (placed in the command line right before the next -i is complete). */
	public List<String> inputArgs() {
		List<String> a = new ArrayList<>();
		if (offsetSec > 0.0005) {
			a.add("-itsoffset");
			a.add(String.format(Locale.ROOT, "%.3f", offsetSec));
		} else if (offsetSec < -0.0005) {
			a.add("-ss");
			a.add(String.format(Locale.ROOT, "%.3f", -offsetSec));
		}
		a.addAll(List.of("-f", format, "-ar", String.valueOf(rate), "-ac", String.valueOf(channels), "-i", pcm.toAbsolutePath().toString()));
		return a;
	}

	/** Output options that encode the audio and make the video decide the final length. */
	public static List<String> outputArgs() {
		return List.of("-af", "apad", "-c:a", "aac", "-b:a", "160k", "-ac", "2", "-shortest");
	}

	/** The small .audio file kept next to a Light-mode recording, so the converter can add the sound later. */
	public void writeMeta(Path meta) throws IOException {
		String text = "format=" + format + "\nrate=" + rate + "\nchannels=" + channels
			+ "\noffsetSec=" + String.format(Locale.ROOT, "%.3f", offsetSec) + "\n";
		Files.writeString(meta, text, StandardCharsets.US_ASCII);
	}

	/** Reads a file written by {@link #writeMeta}; null if it is missing or unusable. */
	public static AudioInput readMeta(Path meta, Path pcm) {
		try {
			if (!Files.isRegularFile(meta) || !Files.isRegularFile(pcm) || Files.size(pcm) == 0) {
				return null;
			}
			String format = null;
			int rate = 0;
			int channels = 0;
			double offset = 0;
			for (String line : Files.readAllLines(meta, StandardCharsets.US_ASCII)) {
				int eq = line.indexOf('=');
				if (eq < 0) {
					continue;
				}
				String k = line.substring(0, eq).trim();
				String v = line.substring(eq + 1).trim();
				switch (k) {
					case "format" -> format = v;
					case "rate" -> rate = Integer.parseInt(v);
					case "channels" -> channels = Integer.parseInt(v);
					case "offsetSec" -> offset = Double.parseDouble(v);
					default -> {
					}
				}
			}
			if (format == null || rate <= 0 || channels <= 0) {
				return null;
			}
			return new AudioInput(pcm, format, rate, channels, offset);
		} catch (Exception e) {
			return null;
		}
	}
}
