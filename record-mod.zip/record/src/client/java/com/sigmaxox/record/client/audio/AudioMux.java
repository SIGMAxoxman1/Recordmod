package com.sigmaxox.record.client.audio;

import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.Recorder;
import com.sigmaxox.record.client.ffmpeg.AudioInput;
import com.sigmaxox.record.client.ffmpeg.FfmpegManager;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/** Live mode: adds the recorded game sound to the finished MP4 (the video is copied, only the sound is encoded). */
public final class AudioMux {
	private AudioMux() {
	}

	public static void muxAsync(Path video, AudioInput audio, Path pcm, Path fmt) {
		Thread t = new Thread(() -> {
			Path temp = video.resolveSibling(video.getFileName().toString().replaceAll("\\.mp4$", "") + ".audio-tmp.mp4");
			try {
				List<String> cmd = new ArrayList<>(List.of(FfmpegManager.command(), "-y", "-hide_banner", "-loglevel", "warning",
					"-i", video.toAbsolutePath().toString()));
				cmd.addAll(audio.inputArgs());
				cmd.addAll(List.of("-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy"));
				cmd.addAll(AudioInput.outputArgs());
				cmd.addAll(List.of("-movflags", "+faststart", temp.toAbsolutePath().toString()));
				Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
				String output = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
				if (!p.waitFor(300, TimeUnit.SECONDS) || p.exitValue() != 0 || !Files.isRegularFile(temp)) {
					p.destroyForcibly();
					throw new IOException(output.isEmpty() ? "FFmpeg could not add the audio" : output);
				}
				Files.move(temp, video, StandardCopyOption.REPLACE_EXISTING);
				Files.deleteIfExists(pcm);
				Files.deleteIfExists(fmt);
				Recorder.INSTANCE.setStatus("Saved with audio: " + video.getFileName(), false, 9000);
			} catch (Exception e) {
				RecordMod.LOGGER.warn("[Record] Adding audio failed", e);
				try {
					Files.deleteIfExists(temp);
				} catch (IOException ignored) {
				}
				Recorder.INSTANCE.setStatus("Saved " + video.getFileName() + " without audio (could not add it: "
					+ String.valueOf(e.getMessage()).lines().findFirst().orElse("error") + ")", true, 12000);
			}
		}, "Record-AudioMux");
		t.setDaemon(true);
		t.start();
	}
}
