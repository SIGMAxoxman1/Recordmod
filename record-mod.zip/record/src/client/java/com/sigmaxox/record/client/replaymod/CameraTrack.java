package com.sigmaxox.record.client.replaymod;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;

/**
 * The exact camera of every rendered frame, saved next to a ReplayMod recording.
 *
 * ReplayMod itself stores the player's movement once per game tick (20 per second) with rounded angles.
 * This track stores position and angles for EVERY frame, on ReplayMod's own timeline
 * (milliseconds since its recording started, pauses excluded), so a replay can show your real view.
 *
 * File: "RMCAM001", long startEpochMs, then records of [int ts][double x][double y][double z][float yaw][float pitch].
 */
public final class CameraTrack {
	public static final byte[] MAGIC = "RMCAM001".getBytes(StandardCharsets.US_ASCII);
	public static final int HEADER_BYTES = 16;
	public static final int RECORD_BYTES = 4 + 8 * 3 + 4 * 2;

	public final long startEpochMs;
	private final int count;
	private final int[] ts;
	private final double[] x;
	private final double[] y;
	private final double[] z;
	private final float[] yaw;
	private final float[] pitch;

	private CameraTrack(long startEpochMs, int count) {
		this.startEpochMs = startEpochMs;
		this.count = count;
		this.ts = new int[count];
		this.x = new double[count];
		this.y = new double[count];
		this.z = new double[count];
		this.yaw = new float[count];
		this.pitch = new float[count];
	}

	public int size() {
		return count;
	}

	public int lastTimestamp() {
		return count == 0 ? 0 : ts[count - 1];
	}

	/** One interpolated camera pose. */
	public record Pose(double x, double y, double z, float yaw, float pitch) {
	}

	/**
	 * The camera at ReplayMod time {@code replayMs}. Null if the track has nothing within a short time of it
	 * (for example the replay is longer than the track), so the normal ReplayMod camera is left alone.
	 */
	public Pose at(long replayMs) {
		if (count == 0) {
			return null;
		}
		if (replayMs < ts[0] - 300 || replayMs > ts[count - 1] + 300) {
			return null;
		}
		int lo = 0;
		int hi = count - 1;
		while (lo < hi) {
			int mid = (lo + hi + 1) >>> 1;
			if (ts[mid] <= replayMs) {
				lo = mid;
			} else {
				hi = mid - 1;
			}
		}
		int i = lo;
		int j = Math.min(i + 1, count - 1);
		double span = ts[j] - ts[i];
		double t = span <= 0 || replayMs <= ts[i] ? 0.0 : Math.min(1.0, (replayMs - ts[i]) / span);
		return new Pose(
			x[i] + (x[j] - x[i]) * t,
			y[i] + (y[j] - y[i]) * t,
			z[i] + (z[j] - z[i]) * t,
			lerpAngle(yaw[i], yaw[j], t),
			(float) (pitch[i] + (pitch[j] - pitch[i]) * t));
	}

	/** Interpolates along the shortest way around the circle (359 -> 1 degrees must not spin the long way). */
	static float lerpAngle(float a, float b, double t) {
		double d = ((b - a) % 360.0 + 540.0) % 360.0 - 180.0;
		return (float) (a + d * t);
	}

	// ---- reading ----

	public static CameraTrack load(Path file) throws IOException {
		byte[] data = Files.readAllBytes(file);
		if (data.length < HEADER_BYTES) {
			throw new IOException("camera track too short");
		}
		ByteBuffer b = ByteBuffer.wrap(data);
		byte[] magic = new byte[MAGIC.length];
		b.get(magic);
		if (!java.util.Arrays.equals(magic, MAGIC)) {
			throw new IOException("not a camera track");
		}
		long start = b.getLong();
		int n = (data.length - HEADER_BYTES) / RECORD_BYTES;   // a half-written last record is ignored
		CameraTrack t = new CameraTrack(start, n);
		for (int i = 0; i < n; i++) {
			t.ts[i] = b.getInt();
			t.x[i] = b.getDouble();
			t.y[i] = b.getDouble();
			t.z[i] = b.getDouble();
			t.yaw[i] = b.getFloat();
			t.pitch[i] = b.getFloat();
		}
		return t;
	}

	/**
	 * Finds the track that belongs to a replay: the file named after its start time, or (if the replay was
	 * trimmed in ReplayMod's editor and its start moved) the track that covers that moment.
	 */
	public static CameraTrack find(Path dir, long replayStartEpochMs) {
		try {
			Path exact = dir.resolve("cam_" + replayStartEpochMs + ".bin");
			if (Files.isRegularFile(exact)) {
				return load(exact);
			}
			if (!Files.isDirectory(dir)) {
				return null;
			}
			try (Stream<Path> files = Files.list(dir)) {
				for (Path f : (Iterable<Path>) files.filter(p -> p.getFileName().toString().endsWith(".bin"))::iterator) {
					long[] range = range(f);
					if (range != null && replayStartEpochMs >= range[0] && replayStartEpochMs <= range[1]) {
						return load(f);
					}
				}
			}
		} catch (IOException ignored) {
		}
		return null;
	}

	/** {start epoch, end epoch} of a track file, read cheaply from its header and last record. */
	private static long[] range(Path f) {
		try (RandomAccessFile r = new RandomAccessFile(f.toFile(), "r")) {
			long len = r.length();
			if (len < HEADER_BYTES + RECORD_BYTES) {
				return null;
			}
			byte[] magic = new byte[MAGIC.length];
			r.readFully(magic);
			if (!java.util.Arrays.equals(magic, MAGIC)) {
				return null;
			}
			long start = r.readLong();
			long records = (len - HEADER_BYTES) / RECORD_BYTES;
			r.seek(HEADER_BYTES + (records - 1) * RECORD_BYTES);
			return new long[] {start, start + r.readInt()};
		} catch (IOException e) {
			return null;
		}
	}

	// ---- writing ----

	/** Appends samples while ReplayMod records. Cheap: about 36 bytes per frame. */
	public static final class Writer implements AutoCloseable {
		private final DataOutputStream out;
		private int lastTs = Integer.MIN_VALUE;
		private int sinceFlush;
		public final Path file;

		public Writer(Path dir, long startEpochMs) throws IOException {
			Files.createDirectories(dir);
			this.file = dir.resolve("cam_" + startEpochMs + ".bin");
			this.out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(file), 1 << 16));
			out.write(MAGIC);
			out.writeLong(startEpochMs);
		}

		/** At most about 250 samples per second (every frame up to 250 fps); time never goes backwards. */
		public void add(int tsMs, double x, double y, double z, float yaw, float pitch) throws IOException {
			if (tsMs < lastTs + 4) {
				return;
			}
			lastTs = tsMs;
			out.writeInt(tsMs);
			out.writeDouble(x);
			out.writeDouble(y);
			out.writeDouble(z);
			out.writeFloat(yaw);
			out.writeFloat(pitch);
			if (++sinceFlush >= 120) {
				out.flush();   // a crash loses at most about one second
				sinceFlush = 0;
			}
		}

		@Override
		public void close() throws IOException {
			out.close();
		}
	}
}
