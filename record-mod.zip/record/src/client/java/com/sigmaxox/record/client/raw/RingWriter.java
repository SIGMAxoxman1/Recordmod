package com.sigmaxox.record.client.raw;

import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.ffmpeg.FrameSink;
import com.sigmaxox.record.client.plan.RecordPlan;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

/**
 * Replay-buffer writer: keeps only the last few minutes of play on disk (a ring of 20-second
 * raw segments), so disk use stays constant no matter how long you play.
 * When a clip is requested, the segments covering the last N seconds are MOVED (instant, no copy)
 * into recordings/clip_<time>/ together with a clip.meta file, ready to be converted to MP4.
 * Stopping the buffer discards whatever was not saved.
 */
public final class RingWriter implements FrameSink {
	public static final long SEGMENT_NS = 20_000_000_000L;

	private record Seg(Path path, long firstTs, long lastTs) {
	}

	private final Path bufferDir;
	private final Path recordingsDir;
	private final RecordPlan plan;
	private final long bufferNs;
	private final long minFreeBytes;
	private final long rgbaBytes;
	private final int i420Bytes;
	private final int maxBuffers;
	private final BlockingQueue<Frame> queue;
	private final BlockingQueue<byte[]> freeBuffers;
	private final AtomicInteger allocated = new AtomicInteger();
	private final List<Seg> closed = new ArrayList<>(); // only touched by the writer thread

	private DataOutputStream out;
	private Path curPath;
	private long curFirstTs;
	private long curLastTs;
	private long curBytes;
	private int segIndex;
	private long closedBytes;

	private volatile boolean finishRequested;
	private volatile boolean done;
	private volatile boolean failed;
	private volatile String failure = "";
	private volatile String limit;
	private volatile long bufferedBytes;
	private volatile long frames;
	private volatile long dropped;
	private volatile long latestTs;
	private volatile long clipRequestNs = -1;
	private volatile Path readyClip;
	private volatile String clipProblem;

	public RingWriter(Path recordingsDir, RecordPlan plan, long bufferNs, long minFreeBytes) {
		this.recordingsDir = recordingsDir;
		this.bufferDir = recordingsDir.resolve(".buffer");
		this.plan = plan;
		this.bufferNs = bufferNs;
		this.minFreeBytes = minFreeBytes;
		this.rgbaBytes = (long) plan.width() * plan.height() * 4L;
		this.i420Bytes = Yuv.i420Size(plan.width(), plan.height());
		this.maxBuffers = (int) Math.max(4, Math.min(8, (192L * 1024 * 1024) / Math.max(1, rgbaBytes)));
		this.queue = new ArrayBlockingQueue<>(maxBuffers);
		this.freeBuffers = new ArrayBlockingQueue<>(maxBuffers);
	}

	@Override
	public void start() throws IOException {
		Files.createDirectories(bufferDir);
		deleteSegments(); // leftovers of a crashed session
		Thread t = new Thread(this::run, "Record-RingWriter");
		t.setDaemon(true);
		t.start();
	}

	/** Asks the writer thread to save the last {@code seconds} seconds as a clip. */
	public void requestClip(double seconds) {
		long ns = (long) Math.min(seconds * 1e9, (double) bufferNs);
		readyClip = null;
		clipProblem = null;
		clipRequestNs = Math.max(1_000_000_000L, ns);
	}

	/** Returns the clip folder once, after a requested clip has been saved. */
	public Path takeReadyClip() {
		Path p = readyClip;
		if (p != null) {
			readyClip = null;
		}
		return p;
	}

	/** Non-null once if the last clip request could not be completed. */
	public String takeClipProblem() {
		String p = clipProblem;
		clipProblem = null;
		return p;
	}

	@Override
	public byte[] acquire() {
		byte[] b = freeBuffers.poll();
		if (b == null && allocated.get() < maxBuffers) {
			allocated.incrementAndGet();
			b = new byte[(int) rgbaBytes];
		}
		return b;
	}

	@Override
	public void release(byte[] buffer) {
		freeBuffers.offer(buffer);
	}

	@Override
	public boolean offer(Frame frame) {
		return !failed && !finishRequested && queue.offer(frame);
	}

	@Override
	public void finish(long endTsNs) {
		finishRequested = true;
	}

	private void run() {
		byte[] i420 = new byte[i420Bytes];
		try {
			while (true) {
				if (clipRequestNs > 0) {
					handleClip();
				}
				Frame f = queue.poll(50, TimeUnit.MILLISECONDS);
				if (f == null) {
					if (failed || (finishRequested && queue.isEmpty())) {
						break;
					}
					continue;
				}
				try {
					if (!failed) {
						writeFrame(f, i420);
					}
				} catch (IOException e) {
					failed = true;
					failure = "Could not write the replay buffer: " + e.getMessage();
					RecordMod.LOGGER.error("[Record] {}", failure);
				} finally {
					release(f.data());
				}
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		} finally {
			try {
				closeSegment();
			} catch (IOException ignored) {
			}
			deleteSegments(); // the buffer is not kept after it is stopped
			bufferedBytes = 0;
			done = true;
		}
	}

	private void writeFrame(Frame f, byte[] i420) throws IOException {
		if (out == null || f.tsNs() - curFirstTs >= SEGMENT_NS) {
			closeSegment();
			prune();
			openSegment(f.tsNs());
		}
		Yuv.rgbaBottomUpToI420(f.data(), plan.width(), plan.height(), i420);
		out.writeLong(f.tsNs());
		out.write(i420, 0, i420Bytes);
		curBytes += 8L + i420Bytes;
		curLastTs = f.tsNs();
		latestTs = f.tsNs();
		frames++;
		bufferedBytes = closedBytes + curBytes;
		if ((frames & 255L) == 0L) {
			try {
				if (Files.getFileStore(bufferDir).getUsableSpace() < minFreeBytes) {
					limit = "Replay buffer stopped: disk space is almost full.";
				}
			} catch (IOException ignored) {
			}
		}
	}

	private void openSegment(long firstTs) throws IOException {
		curPath = bufferDir.resolve(String.format("seg_%08d.rawv", segIndex++));
		out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(curPath), 4 << 20));
		out.write(RawWriter.MAGIC);
		out.writeInt(plan.width());
		out.writeInt(plan.height());
		out.writeInt(plan.fps());
		curFirstTs = firstTs;
		curLastTs = firstTs;
		curBytes = RawWriter.HEADER_BYTES;
	}

	private void closeSegment() throws IOException {
		if (out == null) {
			return;
		}
		out.close();
		out = null;
		closed.add(new Seg(curPath, curFirstTs, curLastTs));
		closedBytes += curBytes;
		curBytes = 0;
	}

	/** Drops the oldest segment while the rest still covers the whole buffer length. */
	private void prune() {
		while (closed.size() >= 2 && latestTs - closed.get(1).firstTs() >= bufferNs) {
			Seg oldest = closed.remove(0);
			try {
				long size = Files.size(oldest.path());
				Files.deleteIfExists(oldest.path());
				closedBytes -= size;
			} catch (IOException ignored) {
			}
		}
	}

	private void handleClip() {
		long clipNs = clipRequestNs;
		clipRequestNs = -1;
		try {
			closeSegment();
			if (closed.isEmpty()) {
				clipProblem = "Nothing buffered yet - play a few seconds first.";
				return;
			}
			long endTs = latestTs;
			long startTs = Math.max(closed.get(0).firstTs(), endTs - clipNs);
			List<Seg> chosen = new ArrayList<>();
			for (Seg s : closed) {
				if (s.lastTs() >= startTs) {
					chosen.add(s);
				}
			}
			String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
			Path clipDir = recordingsDir.resolve("clip_" + stamp);
			Files.createDirectories(clipDir);
			Files.writeString(clipDir.resolve("clip.meta"), "startTsNs=" + startTs + "\n");
			for (Seg s : chosen) {
				long size = Files.size(s.path());
				Files.move(s.path(), clipDir.resolve(s.path().getFileName()));
				closedBytes -= size;
			}
			closed.removeAll(chosen);
			bufferedBytes = closedBytes;
			readyClip = clipDir;
		} catch (IOException e) {
			clipProblem = "Could not save the clip: " + e.getMessage();
			RecordMod.LOGGER.error("[Record] {}", clipProblem, e);
		}
	}

	private void deleteSegments() {
		try (Stream<Path> files = Files.list(bufferDir)) {
			files.filter(f -> f.getFileName().toString().startsWith("seg_")).forEach(f -> {
				try {
					Files.deleteIfExists(f);
				} catch (IOException ignored) {
				}
			});
		} catch (IOException ignored) {
		}
		closed.clear();
		closedBytes = 0;
	}

	@Override
	public boolean isDone() {
		return done;
	}

	@Override
	public boolean hasFailed() {
		return failed;
	}

	@Override
	public String failureMessage() {
		return failure;
	}

	@Override
	public long framesWritten() {
		return frames;
	}

	@Override
	public Path file() {
		return bufferDir;
	}

	@Override
	public boolean awaitDone(long timeoutMs) {
		long end = System.currentTimeMillis() + timeoutMs;
		while (!done && System.currentTimeMillis() < end) {
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				break;
			}
		}
		return done;
	}

	@Override
	public long droppedFrames() {
		return dropped;
	}

	@Override
	public void setDroppedFrames(long dropped) {
		this.dropped = dropped;
	}

	@Override
	public String limitReached() {
		return limit;
	}

	/** Size of what is currently buffered on disk. */
	@Override
	public long bytesWritten() {
		return bufferedBytes;
	}
}
