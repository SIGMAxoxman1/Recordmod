package com.sigmaxox.record.client.replaymod;

import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.config.RecordConfig;
import java.io.IOException;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Camera;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Companion for ReplayMod: records the real camera of every frame while ReplayMod records,
 * and shows that exact camera while a replay plays. This fixes the delayed jumps, missing aim shake
 * and off crosshair of normal replays, which come from ReplayMod storing movement only once per tick.
 */
public final class CameraCompanion {
	private CameraCompanion() {
	}

	private static Path dir() {
		return FabricLoader.getInstance().getGameDir().resolve("record").resolve("camera");
	}

	// ---- recording ----
	private static CameraTrack.Writer writer;
	private static long writerStart = Long.MIN_VALUE;

	/** Called after every rendered frame (render thread). */
	public static void onFrameEnd(Minecraft mc) {
		try {
			if (!RecordConfig.get().replayCamera) {
				closeWriter();
				return;
			}
			long start = ReplayModBridge.recordingStart();
			if (start < 0 || mc.level == null) {
				if (start < 0) {
					closeWriter();
				}
				return;
			}
			if (writer == null || writerStart != start) {
				closeWriter();
				writer = new CameraTrack.Writer(dir(), start);
				writerStart = start;
				RecordMod.LOGGER.info("[Record] Recording the camera of every frame next to the ReplayMod recording: {}", writer.file);
			}
			// Same clock ReplayMod uses for its packets: ms since its start, minus time the game was paused.
			long ts = System.currentTimeMillis() - start - ReplayModBridge.recordingPausedMs();
			Camera camera = mc.gameRenderer.mainCamera();
			Vec3 p = camera.position();
			writer.add((int) ts, p.x, p.y, p.z, camera.yRot(), camera.xRot());
		} catch (IOException e) {
			RecordMod.LOGGER.warn("[Record] Could not write the camera track", e);
			writer = null;
		} catch (Throwable t) {
			RecordMod.LOGGER.warn("[Record] Camera track recording failed", t);
			writer = null;
		}
	}

	private static void closeWriter() {
		if (writer != null) {
			try {
				writer.close();
			} catch (IOException ignored) {
			}
			writer = null;
			writerStart = Long.MIN_VALUE;
		}
	}

	// ---- replay ----
	private static Object lastHandler;
	private static CameraTrack track;
	private static long replayStart = -1;
	private static CameraType savedCameraType;
	private static boolean loggedMissing;
	private static Object preRenderToken;

	/** Runs at the start of every frame of a replay (preview and export), after ReplayMod's own camera update. */
	private static void onPreRender() {
		applyReplayCamera(Minecraft.getInstance());
	}

	/** Puts ReplayMod's camera at the recorded pose for the current replay time (render thread). */
	public static void applyReplayCamera(Minecraft mc) {
		try {
			Object handler = RecordConfig.get().replayCamera ? ReplayModBridge.replayHandler() : null;
			if (handler == null) {
				endReplay(mc);
				return;
			}
			if (handler != lastHandler) {
				startReplay(mc, handler);
			}
			if (track == null) {
				return;
			}
			Object cameraObj = ReplayModBridge.cameraEntity(handler);
			if (!(cameraObj instanceof Entity camera)) {
				return;
			}
			if (preRenderToken == null) {
				// Registered now, after ReplayMod created its camera, so we run after ReplayMod's own per-frame update
				// and in its export loop too.
				preRenderToken = ReplayModBridge.registerPreRender(CameraCompanion::onPreRender);
			}
			int t = ReplayModBridge.replayTime(handler);
			if (t < 0) {
				return;
			}
			CameraTrack.Pose pose = track.at(t + (replayStart - track.startEpochMs));
			if (pose == null) {
				return;
			}
			if (mc.getCameraEntity() != camera) {
				ReplayModBridge.useFreeCamera(handler);
			}
			if (mc.options.getCameraType() != CameraType.FIRST_PERSON) {
				mc.options.setCameraType(CameraType.FIRST_PERSON);   // the recorded camera already contains the 3rd-person offset
			}
			// the camera entity stands on its feet; the view sits at eye height above them
			ReplayModBridge.setCamera(camera, pose.x(), pose.y() - camera.getEyeHeight(), pose.z(), pose.yaw(), pose.pitch());
		} catch (Throwable t) {
			RecordMod.LOGGER.warn("[Record] Replay camera failed, leaving ReplayMod's own camera", t);
			track = null;
		}
	}

	private static void startReplay(Minecraft mc, Object handler) {
		lastHandler = handler;
		track = null;
		savedCameraType = mc.options.getCameraType();
		replayStart = ReplayModBridge.replayStart(handler);
		if (replayStart < 0) {
			return;
		}
		track = CameraTrack.find(dir(), replayStart);
		if (track == null) {
			if (!loggedMissing) {
				loggedMissing = true;
				RecordMod.LOGGER.info("[Record] This replay has no per-frame camera track (it was not recorded with this mod) - using ReplayMod's normal camera.");
			}
		} else {
			RecordMod.LOGGER.info("[Record] Using the recorded per-frame camera for this replay ({} samples).", track.size());
		}
	}

	private static void endReplay(Minecraft mc) {
		if (preRenderToken != null) {
			ReplayModBridge.unregisterPreRender(preRenderToken);
			preRenderToken = null;
		}
		if (lastHandler != null) {
			lastHandler = null;
			track = null;
			loggedMissing = false;
			if (savedCameraType != null) {
				mc.options.setCameraType(savedCameraType);
				savedCameraType = null;
			}
		}
	}
}
