package com.sigmaxox.record.client.audio;

import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.ffmpeg.AudioInput;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Captures the game's sound (everything playing on the default Windows output) with a tiny helper program.
 *
 * The helper is C# source bundled in the mod; the first time, it is compiled with csc.exe, which ships with
 * every Windows (.NET Framework 4). It runs as a separate process, so a problem there can never crash the game.
 * Windows only.
 */
public final class AudioCapture {
	public enum HelperState {
		UNKNOWN, BUILDING, READY, UNAVAILABLE
	}

	private static volatile HelperState helperState = HelperState.UNKNOWN;
	private static volatile Path exe;
	private static volatile String problem = "";
	private static boolean started;

	public static HelperState helperState() {
		return helperState;
	}

	/** Why audio is not available (or "still preparing"). */
	public static String problem() {
		return helperState == HelperState.BUILDING ? "the audio helper is still being prepared" : problem;
	}

	private static boolean isWindows() {
		return System.getProperty("os.name", "").toLowerCase().contains("win");
	}

	/** Starts preparing the helper in the background (called when the game starts). */
	public static synchronized void init() {
		if (started) {
			return;
		}
		started = true;
		if (!isWindows()) {
			problem = "game audio capture is available on Windows only";
			helperState = HelperState.UNAVAILABLE;
			return;
		}
		helperState = HelperState.BUILDING;
		Thread t = new Thread(AudioCapture::build, "Record-AudioHelper");
		t.setDaemon(true);
		t.start();
	}

	private static String findCsc() {
		String windir = System.getenv("WINDIR");
		if (windir == null || windir.isBlank()) {
			windir = System.getenv("SystemRoot");
		}
		if (windir == null || windir.isBlank()) {
			windir = "C:\\Windows";
		}
		for (String framework : new String[] {"Framework64", "Framework"}) {
			Path csc = Path.of(windir, "Microsoft.NET", framework, "v4.0.30319", "csc.exe");
			if (Files.isRegularFile(csc)) {
				return csc.toString();
			}
		}
		return null;
	}

	private static void build() {
		try {
			Path dir = FabricLoader.getInstance().getGameDir().resolve("record").resolve("audio");
			Files.createDirectories(dir);
			String source;
			try (InputStream in = AudioCapture.class.getResourceAsStream("/assets/record/audio/AudioLoopback.cs")) {
				if (in == null) {
					throw new IOException("the helper source is missing from the mod");
				}
				source = new String(in.readAllBytes(), StandardCharsets.UTF_8);
			}
			String version = Integer.toHexString(source.hashCode());
			Path cs = dir.resolve("AudioLoopback.cs");
			Path built = dir.resolve("AudioLoopback.exe");
			Path versionFile = dir.resolve("AudioLoopback.version");

			if (Files.isRegularFile(built) && Files.isRegularFile(versionFile)
				&& Files.readString(versionFile).trim().equals(version)) {
				exe = built;
				helperState = HelperState.READY;
				return;
			}

			String csc = findCsc();
			if (csc == null) {
				problem = "Windows' built-in C# compiler (.NET Framework 4) was not found";
				helperState = HelperState.UNAVAILABLE;
				return;
			}
			Files.writeString(cs, source, StandardCharsets.UTF_8);
			Process p = new ProcessBuilder(csc, "/nologo", "/target:exe", "/optimize+", "/out:" + built, cs.toString())
				.redirectErrorStream(true).start();
			String output = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
			if (!p.waitFor(90, TimeUnit.SECONDS) || p.exitValue() != 0 || !Files.isRegularFile(built)) {
				RecordMod.LOGGER.warn("[Record] Audio helper build failed: {}", output);
				problem = "the audio helper could not be built";
				helperState = HelperState.UNAVAILABLE;
				return;
			}
			Files.writeString(versionFile, version);
			exe = built;
			helperState = HelperState.READY;
			RecordMod.LOGGER.info("[Record] Audio helper ready: {}", built);
		} catch (Throwable t) {
			RecordMod.LOGGER.warn("[Record] Audio helper setup failed", t);
			problem = String.valueOf(t.getMessage());
			helperState = HelperState.UNAVAILABLE;
		}
	}

	// ---- one capture session ----

	private final Process process;
	private final Path fmtFile;
	private volatile boolean startedCapturing;
	private volatile boolean finished;
	private volatile String error;

	private AudioCapture(Process process, Path fmtFile) {
		this.process = process;
		this.fmtFile = fmtFile;
		Thread reader = new Thread(() -> {
			try (BufferedReader r = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
				String line;
				while ((line = r.readLine()) != null) {
					if (line.startsWith("started")) {
						startedCapturing = true;
					} else if (line.startsWith("error:")) {
						error = line.substring(6).trim();
					}
				}
			} catch (IOException ignored) {
			}
			try {
				process.waitFor(5, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
			if (!startedCapturing && error == null) {
				error = "the audio helper stopped unexpectedly";
			}
			finished = true;
		}, "Record-AudioReader");
		reader.setDaemon(true);
		reader.start();
	}

	/** Starts capturing right now. Only valid when helperState() == READY. */
	public static AudioCapture start(Path pcm, Path fmt) throws IOException {
		if (helperState != HelperState.READY || exe == null) {
			throw new IOException(problem());
		}
		Files.deleteIfExists(fmt);
		Process p = new ProcessBuilder(exe.toString(), pcm.toAbsolutePath().toString(), fmt.toAbsolutePath().toString())
			.redirectErrorStream(true).start();
		return new AudioCapture(p, fmt);
	}

	/** Asks the helper to finish; it writes the last audio and exits within a moment. */
	public void stop() {
		try {
			OutputStream stdin = process.getOutputStream();
			stdin.write("stop\n".getBytes(StandardCharsets.US_ASCII));
			stdin.flush();
			stdin.close();
		} catch (IOException ignored) {
		}
		Thread watchdog = new Thread(() -> {
			try {
				if (!process.waitFor(8, TimeUnit.SECONDS)) {
					process.destroyForcibly();
				}
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}, "Record-AudioStop");
		watchdog.setDaemon(true);
		watchdog.start();
	}

	public boolean isFinished() {
		return finished;
	}

	public boolean hasStarted() {
		return startedCapturing;
	}

	/** Non-null if the helper could not capture (for example no output device). */
	public String error() {
		return error;
	}

	/** Reads what the helper wrote (format, sample rate, when it started). Null if nothing usable. */
	public Info info() {
		try {
			if (!Files.isRegularFile(fmtFile)) {
				return null;
			}
			String format = null;
			int rate = 0;
			int channels = 0;
			long startEpochMs = 0;
			for (String line : Files.readAllLines(fmtFile, StandardCharsets.US_ASCII)) {
				int eq = line.indexOf('=');
				if (eq < 0) {
					continue;
				}
				String k = line.substring(0, eq).trim();
				String v = line.substring(eq + 1).trim();
				switch (k) {
					case "format" -> format = v;
					case "rate" -> rate = Integer.parseInt(v);
					case "channels" -> channels = Integer.parseInt(v);
					case "startEpochMs" -> startEpochMs = Long.parseLong(v);
					default -> {
					}
				}
			}
			if (format == null || rate <= 0 || channels <= 0 || startEpochMs <= 0) {
				return null;
			}
			return new Info(format, rate, channels, startEpochMs);
		} catch (Exception e) {
			return null;
		}
	}

	public record Info(String format, int rate, int channels, long startEpochMs) {
		/** Audio start relative to the video start, in seconds. */
		public AudioInput toInput(Path pcm, long videoStartEpochMs) {
			return new AudioInput(pcm, format, rate, channels, (startEpochMs - videoStartEpochMs) / 1000.0);
		}
	}
}
