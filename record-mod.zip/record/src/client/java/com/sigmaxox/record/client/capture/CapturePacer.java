package com.sigmaxox.record.client.capture;

/**
 * Decides which game frames to capture so the video has an even rhythm.
 *
 * The video runs on a fixed grid (for example one frame every 33.3 ms at 30 fps). For every grid slot the
 * recorder takes the game frame that lands closest to it and stamps it with the grid time. That keeps the
 * spacing perfectly regular even when the game runs at 45 or 50 fps - capturing "whenever a frame is due"
 * gives an uneven 20 ms / 40 ms pattern that looks like stutter.
 * If the game is slower than the grid, the frame keeps its real time and the encoder repeats it to fill the gap.
 */
public final class CapturePacer {
	private final long baseIntervalNs;
	private long slot;
	private int stride = 1;
	private long frameEmaNs;

	public CapturePacer(long intervalNs) {
		this.baseIntervalNs = intervalNs;
	}

	/** Average time the game takes per frame (used to pick the frame nearest to the grid time). */
	public void setFrameEma(long ns) {
		this.frameEmaNs = ns;
	}

	/** 2 = capture every other grid slot (used when the game itself is struggling). */
	public void setStride(int newStride) {
		if (newStride != stride) {
			stride = newStride;
			slot = lastRel / (baseIntervalNs * stride) + 1;
		}
	}

	private long lastRel;

	/**
	 * Returns the timestamp for this frame (ns since the recording started), or -1 if the frame should be skipped.
	 * Does not change any state; call {@link #accept} once the frame was really captured.
	 */
	public long due(long relNs) {
		lastRel = relNs;
		long interval = baseIntervalNs * stride;
		if (frameEmaNs >= interval) {
			return relNs;   // the game is slower than the video rate: take every frame at its real time
		}
		long gridTime = slot * interval;
		long half = Math.min(frameEmaNs / 2, interval / 2);
		if (relNs < gridTime - half) {
			return -1;
		}
		return relNs - gridTime > interval / 2 ? relNs : gridTime;
	}

	/** The frame stamped {@code ts} (from {@link #due}) was captured. */
	public void accept(long relNs, long ts) {
		long interval = baseIntervalNs * stride;
		if (ts == slot * interval) {
			slot++;                        // on-time frame, stamped with its grid time
		} else {
			slot = relNs / interval + 1;   // late frame (slow game), stamped with its real time
		}
	}
}
