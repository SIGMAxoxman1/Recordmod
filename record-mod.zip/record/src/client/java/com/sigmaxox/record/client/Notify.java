package com.sigmaxox.record.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** Short messages in the game chat, so you can see what the mod is doing. Render thread only. */
public final class Notify {
	private Notify() {
	}

	public static void chat(String text) {
		try {
			Minecraft mc = Minecraft.getInstance();
			if (mc.gui != null) {
				mc.gui.hud.getChat().addClientSystemMessage(Component.literal("[Record] " + text));
			}
		} catch (Throwable ignored) {
			// a message must never cause a problem
		}
	}
}
