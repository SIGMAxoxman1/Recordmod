package com.sigmaxox.record.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** Messages for the player: in the chat while in a world, and as a line in the top-right corner on any screen. */
public final class Notify {
	private Notify() {
	}

	private static volatile String status = "";
	private static volatile boolean error;
	private static volatile long until;

	public static String statusText() {
		return System.currentTimeMillis() < until ? status : "";
	}

	public static boolean statusIsError() {
		return error;
	}

	/** Only the corner line (progress texts that change often). Safe from any thread. */
	public static void status(String text, boolean isError, long millis) {
		status = text;
		error = isError;
		until = System.currentTimeMillis() + millis;
	}

	/** Corner line + chat message (if in a world). Render thread only. */
	public static void chat(String text) {
		status(text, false, 9000);
		say(text);
	}

	public static void problem(String text) {
		status(text, true, 14000);
		say(text);
	}

	private static void say(String text) {
		try {
			Minecraft mc = Minecraft.getInstance();
			if (mc.gui != null && mc.level != null) {
				mc.gui.hud.getChat().addClientSystemMessage(Component.literal("[Record] " + text));
			}
		} catch (Throwable ignored) {
			// a message must never cause a problem
		}
	}
}
