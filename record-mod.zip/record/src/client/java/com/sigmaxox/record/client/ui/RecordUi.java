package com.sigmaxox.record.client.ui;

import com.sigmaxox.record.client.Recorder;
import com.sigmaxox.record.client.config.RecordConfig;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Builds the buttons that the mixins add to the title screen and the pause menu. */
public final class RecordUi {
	private RecordUi() {
	}

	private static final List<WeakReference<Button>> RECORD_BUTTONS = new ArrayList<>();

	private static Component recordLabel() {
		boolean replayMode = RecordConfig.get().mode == RecordConfig.Mode.REPLAY;
		if (Recorder.INSTANCE.isRecording()) {
			return Component.literal(replayMode ? "\u25A0 Stop Replay" : "\u25A0 Stop Recording");
		}
		return Component.literal(replayMode ? "\u25CF Start Replay" : "\u25CF Record Now");
	}

	public static Button recordButton(int x, int y, int width) {
		Button button = Button.builder(recordLabel(), b -> Recorder.INSTANCE.toggle(Minecraft.getInstance()))
			.bounds(x, y, width, 20)
			.build();
		RECORD_BUTTONS.add(new WeakReference<>(button));
		return button;
	}

	public static Button clipButton(int x, int y, int width) {
		return Button.builder(Component.literal("Save Clip"), b -> Recorder.INSTANCE.saveClip())
			.bounds(x, y, width, 20)
			.build();
	}

	public static Button settingsButton(int x, int y, Screen parent) {
		return Button.builder(Component.literal("\u2699"), b -> Minecraft.getInstance().gui.setScreen(new RecordSettingsScreen(parent)))
			.bounds(x, y, 20, 20)
			.build();
	}

	/** Updates the label of every visible Record button. */
	public static void refreshButtons() {
		Component label = recordLabel();
		RECORD_BUTTONS.removeIf(ref -> {
			Button b = ref.get();
			if (b == null) {
				return true;
			}
			b.setMessage(label);
			return false;
		});
	}
}
