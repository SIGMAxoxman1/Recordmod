package com.sigmaxox.record.client.ui;

import com.sigmaxox.record.client.config.RecordConfig;
import com.sigmaxox.record.client.ffmpeg.FfmpegManager;
import com.sigmaxox.record.client.hw.HardwareDetect;
import com.sigmaxox.record.client.plan.RecordPlan;
import com.sigmaxox.record.client.raw.RawConverter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Supplier;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;

/**
 * Every option starts on "Auto": the mod reads the PC and picks the settings itself.
 * Advanced users can override any row.
 */
public class RecordSettingsScreen extends Screen {
	private final Screen parent;
	private Button ffmpegButton;
	private Button convertButton;

	public RecordSettingsScreen(Screen parent) {
		super(Component.literal("Record Settings"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		RecordConfig cfg = RecordConfig.get();
		int cx = this.width / 2;
		int w = 154;
		int left = cx - w - 2;
		int right = cx + 2;

		this.addRenderableWidget(center(this.title.getString(), 10));

		HardwareDetect.Info hw = HardwareDetect.detect(this.minecraft);
		this.addRenderableWidget(center("PC: " + hw.gpuName() + " - " + hw.cpuCores() + " cores - rated " + hw.tier().label, 24));

		int srcW = this.minecraft.getWindow().getWidth();
		int srcH = this.minecraft.getWindow().getHeight();
		String planLine;
		if (cfg.mode == RecordConfig.Mode.REPLAY) {
			planLine = "Replay: " + RecordPlan.light(cfg, hw, srcW, srcH).describeReplay(cfg.bufferMinutes);
		} else if (cfg.mode == RecordConfig.Mode.LIGHT) {
			planLine = "Will record: " + RecordPlan.light(cfg, hw, srcW, srcH).describeLight();
		} else if (FfmpegManager.state() == FfmpegManager.State.READY) {
			planLine = "Will record: " + RecordPlan.build(cfg, hw, FfmpegManager.encoders(), srcW, srcH).describeLive(cfg.targetGbPer10Min);
		} else {
			planLine = "Live MP4 needs FFmpeg - see the FFmpeg button below";
		}
		this.addRenderableWidget(center(planLine, 36));

		int y = 54;
		int step = 22;
		cycle(left, y, w, () -> "Mode: " + cfg.mode.label, () -> cfg.mode = RecordConfig.next(cfg.mode));
		cycle(right, y, w, () -> "Resolution: " + cfg.resolution.label, () -> cfg.resolution = RecordConfig.next(cfg.resolution));
		y += step;
		cycle(left, y, w, () -> "Frame rate: " + cfg.fps.label, () -> cfg.fps = RecordConfig.next(cfg.fps));
		cycle(right, y, w, () -> "Encoder: " + cfg.encoder.label, () -> cfg.encoder = RecordConfig.next(cfg.encoder));
		y += step;
		cycle(left, y, w, () -> cfg.targetGbPer10Min > 0 ? "Size: " + trim(cfg.targetGbPer10Min) + " GB/10 min" : "Size: by quality",
			() -> cfg.targetGbPer10Min = nextOf(cfg.targetGbPer10Min, 0.5, 1, 1.5, 2, 3, 0));
		cycle(right, y, w, () -> "REC dot in video: " + (cfg.showIndicator ? "ON" : "OFF"), () -> cfg.showIndicator = !cfg.showIndicator);
		y += step;
		cycle(left, y, w, () -> "Auto-convert: " + (cfg.autoConvert ? "ON" : "OFF"), () -> cfg.autoConvert = !cfg.autoConvert);
		this.ffmpegButton = this.addRenderableWidget(Button.builder(ffmpegLabel(), b -> {
			FfmpegManager.downloadAsync();
			b.setMessage(ffmpegLabel());
		}).bounds(right, y, w, 20).build());
		y += step;

		cycle(left, y, w, () -> "Buffer: " + trim(cfg.bufferMinutes) + " min", () -> cfg.bufferMinutes = nextOf(cfg.bufferMinutes, 2, 3, 5, 10, 15));
		cycle(right, y, w, () -> "Clip length: " + formatClip(cfg.clipSeconds), () -> cfg.clipSeconds = nextOf(cfg.clipSeconds, 30, 60, 120, 180, 300));
		y += step;

		this.convertButton = this.addRenderableWidget(Button.builder(convertLabel(), b -> RawConverter.convertPending(this.minecraft))
			.bounds(left, y, w, 20).build());
		this.addRenderableWidget(Button.builder(Component.literal("Open recordings folder"), b -> {
			try {
				Path dir = RecordConfig.recordingsDir();
				Files.createDirectories(dir);
				Util.getPlatform().openPath(dir);
			} catch (Exception ignored) {
			}
		}).bounds(right, y, w, 20).build());
		y += step + 6;

		this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> this.onClose())
			.bounds(cx - w - 2, y, 2 * w + 4, 20).build());
	}

	private void cycle(int x, int y, int w, Supplier<String> label, Runnable change) {
		this.addRenderableWidget(Button.builder(Component.literal(label.get()), b -> {
			change.run();
			RecordConfig.get().save();
			b.setMessage(Component.literal(label.get()));
			// Rebuild so the "Will record" line reflects the new choice.
			this.rebuildWidgets();
		}).bounds(x, y, w, 20).build());
	}

	private static double nextOf(double current, double... options) {
		for (int i = 0; i < options.length; i++) {
			if (Math.abs(options[i] - current) < 0.01) {
				return options[(i + 1) % options.length];
			}
		}
		return options[0];
	}

	private static String trim(double v) {
		return v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v);
	}

	private static String formatClip(double seconds) {
		return seconds >= 90 ? trim(seconds / 60.0) + " min" : trim(seconds) + " s";
	}

	private StringWidget center(String text, int y) {
		Component c = Component.literal(text);
		int tw = this.font.width(text);
		return new StringWidget(this.width / 2 - tw / 2, y, tw, 9, c, this.font);
	}

	private static Component ffmpegLabel() {
		return switch (FfmpegManager.state()) {
			case READY -> Component.literal("FFmpeg: ready");
			case DOWNLOADING -> Component.literal("FFmpeg: " + FfmpegManager.progress() + "%");
			case PROBING, SEARCHING -> Component.literal("FFmpeg: checking...");
			case FAILED -> Component.literal("FFmpeg failed - retry");
			default -> Component.literal("Download FFmpeg");
		};
	}

	private static Component convertLabel() {
		if (RawConverter.isRunning()) {
			return Component.literal("Converting... " + RawConverter.progress() + "%");
		}
		int n = RawConverter.pending().size();
		return Component.literal("Convert recordings (" + n + ")");
	}

	@Override
	public void tick() {
		super.tick();
		if (this.ffmpegButton != null) {
			this.ffmpegButton.setMessage(ffmpegLabel());
			FfmpegManager.State s = FfmpegManager.state();
			this.ffmpegButton.active = s == FfmpegManager.State.MISSING || s == FfmpegManager.State.FAILED || s == FfmpegManager.State.UNKNOWN;
		}
		if (this.convertButton != null && RawConverter.isRunning()) {
			this.convertButton.setMessage(convertLabel());
		}
	}

	@Override
	public void onClose() {
		this.minecraft.gui.setScreen(this.parent);
	}
}
