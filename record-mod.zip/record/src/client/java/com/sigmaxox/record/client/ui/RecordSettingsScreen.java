package com.sigmaxox.record.client.ui;

import com.sigmaxox.record.client.config.RecordConfig;
import com.sigmaxox.record.client.ffmpeg.FfmpegManager;
import com.sigmaxox.record.client.hw.HardwareDetect;
import com.sigmaxox.record.client.plan.RecordPlan;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Supplier;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;

/**
 * Every option starts on "Auto": the mod reads the PC and picks the settings itself.
 * Advanced users can override any row.
 */
public class RecordSettingsScreen extends Screen {
	private final Screen parent;
	private Button ffmpegButton;

	public RecordSettingsScreen(Screen parent) {
		super(Component.literal("Record Settings"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		RecordConfig cfg = RecordConfig.get();
		int cx = this.width / 2;
		int w = 220;
		int x = cx - w / 2;

		this.addRenderableWidget(center(this.title.getString(), 12));

		HardwareDetect.Info hw = HardwareDetect.detect(this.minecraft);
		this.addRenderableWidget(center("PC: " + hw.gpuName() + " - " + hw.cpuCores() + " cores - rated " + hw.tier().label, 26));
		String autoLine;
		if (FfmpegManager.state() == FfmpegManager.State.READY) {
			RecordPlan plan = RecordPlan.build(cfg, hw, FfmpegManager.encoders(),
				this.minecraft.getWindow().getWidth(), this.minecraft.getWindow().getHeight());
			autoLine = "Will record: " + plan.describe();
		} else {
			autoLine = "FFmpeg not ready yet - see the FFmpeg button below";
		}
		this.addRenderableWidget(center(autoLine, 38));

		int y = 56;
		int step = 22;
		y = cycle(x, y, w, step, () -> "Resolution: " + cfg.resolution.label, () -> cfg.resolution = RecordConfig.next(cfg.resolution));
		y = cycle(x, y, w, step, () -> "Frame rate: " + cfg.fps.label, () -> cfg.fps = RecordConfig.next(cfg.fps));
		y = cycle(x, y, w, step, () -> "Encoder: " + cfg.encoder.label, () -> cfg.encoder = RecordConfig.next(cfg.encoder));
		y = cycle(x, y, w, step, () -> "Quality: " + cfg.quality.label, () -> cfg.quality = RecordConfig.next(cfg.quality));
		y = cycle(x, y, w, step, () -> "REC indicator in video: " + (cfg.showIndicator ? "ON" : "OFF"), () -> cfg.showIndicator = !cfg.showIndicator);

		this.ffmpegButton = this.addRenderableWidget(Button.builder(ffmpegLabel(), b -> {
			FfmpegManager.downloadAsync();
			b.setMessage(ffmpegLabel());
		}).bounds(x, y, w, 20).build());
		y += step;

		this.addRenderableWidget(Button.builder(Component.literal("Open recordings folder"), b -> {
			try {
				Path dir = cfg.outputDir.isBlank()
					? FabricLoader.getInstance().getGameDir().resolve("recordings")
					: Path.of(cfg.outputDir);
				Files.createDirectories(dir);
				Util.getPlatform().openPath(dir);
			} catch (Exception ignored) {
			}
		}).bounds(x, y, w, 20).build());
		y += step + 6;

		this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> this.onClose())
			.bounds(x, y, w, 20).build());
	}

	private int cycle(int x, int y, int w, int step, Supplier<String> label, Runnable change) {
		this.addRenderableWidget(Button.builder(Component.literal(label.get()), b -> {
			change.run();
			RecordConfig.get().save();
			b.setMessage(Component.literal(label.get()));
			// Rebuild so the "Will record" line reflects the new choice.
			this.rebuildWidgets();
		}).bounds(x, y, w, 20).build());
		return y + step;
	}

	private StringWidget center(String text, int y) {
		Component c = Component.literal(text);
		int tw = this.font.width(text);
		return new StringWidget(this.width / 2 - tw / 2, y, tw, 9, c, this.font);
	}

	private static Component ffmpegLabel() {
		return switch (FfmpegManager.state()) {
			case READY -> Component.literal("FFmpeg: ready");
			case DOWNLOADING -> Component.literal("FFmpeg: downloading... " + FfmpegManager.progress() + "%");
			case PROBING, SEARCHING -> Component.literal("FFmpeg: checking...");
			case FAILED -> Component.literal("FFmpeg: failed - click to retry");
			default -> Component.literal("Download FFmpeg (needed once)");
		};
	}

	@Override
	public void tick() {
		super.tick();
		if (this.ffmpegButton != null) {
			this.ffmpegButton.setMessage(ffmpegLabel());
			FfmpegManager.State s = FfmpegManager.state();
			this.ffmpegButton.active = s == FfmpegManager.State.MISSING || s == FfmpegManager.State.FAILED || s == FfmpegManager.State.UNKNOWN;
		}
	}

	@Override
	public void onClose() {
		this.minecraft.gui.setScreen(this.parent);
	}
}
