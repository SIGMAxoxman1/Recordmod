package com.sigmaxox.record.client.ffmpeg;

import com.sigmaxox.record.RecordMod;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import net.fabricmc.loader.api.FabricLoader;

/** Finds FFmpeg (own folder, then PATH) and downloads it on Windows if missing. ReplayMod needs it to write MP4. */
public final class FfmpegLocator {
	private FfmpegLocator() {
	}

	public enum State {
		IDLE, DOWNLOADING, READY, FAILED
	}

	private static final String[] URLS = {
		"https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
		"https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
	};

	private static volatile State state = State.IDLE;
	private static volatile int progress;
	private static volatile String error = "";

	public static State state() {
		return state;
	}

	public static int progress() {
		return progress;
	}

	public static String error() {
		return error;
	}

	private static boolean isWindows() {
		return System.getProperty("os.name", "").toLowerCase().contains("win");
	}

	private static Path dir() {
		return FabricLoader.getInstance().getGameDir().resolve("record").resolve("ffmpeg");
	}

	/** The command to run FFmpeg, or null if it is not available yet. */
	public static String find() {
		Path own = dir().resolve(isWindows() ? "ffmpeg.exe" : "ffmpeg");
		if (Files.isRegularFile(own)) {
			return own.toAbsolutePath().toString();
		}
		try {
			Process p = new ProcessBuilder("ffmpeg", "-version").redirectErrorStream(true)
				.redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
			if (p.waitFor(15, TimeUnit.SECONDS) && p.exitValue() == 0) {
				return "ffmpeg";
			}
			p.destroyForcibly();
		} catch (Exception ignored) {
		}
		return null;
	}

	public static synchronized void downloadAsync() {
		if (state == State.DOWNLOADING) {
			return;
		}
		if (!isWindows()) {
			error = "Install FFmpeg and add it to PATH.";
			state = State.FAILED;
			return;
		}
		state = State.DOWNLOADING;
		progress = 0;
		error = "";
		Thread t = new Thread(FfmpegLocator::download, "Record-FFmpeg");
		t.setDaemon(true);
		t.start();
	}

	private static void download() {
		Exception last = null;
		for (String url : URLS) {
			try {
				Files.createDirectories(dir());
				Path zip = dir().resolve("ffmpeg-download.zip");
				progress = 0;
				HttpClient client = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.ALWAYS)
					.connectTimeout(Duration.ofSeconds(20)).build();
				HttpResponse<InputStream> r = client.send(
					HttpRequest.newBuilder(URI.create(url)).header("User-Agent", "record-mod").GET().build(),
					HttpResponse.BodyHandlers.ofInputStream());
				if (r.statusCode() != 200) {
					throw new IOException("HTTP " + r.statusCode());
				}
				long total = r.headers().firstValueAsLong("Content-Length").orElse(-1L);
				try (InputStream in = r.body(); OutputStream out = Files.newOutputStream(zip)) {
					byte[] buf = new byte[1 << 16];
					long done = 0;
					int n;
					while ((n = in.read(buf)) > 0) {
						out.write(buf, 0, n);
						done += n;
						if (total > 0) {
							progress = (int) (done * 100L / total);
						}
					}
				}
				extract(zip, dir().resolve("ffmpeg.exe"));
				Files.deleteIfExists(zip);
				state = State.READY;
				return;
			} catch (Exception e) {
				last = e;
				RecordMod.LOGGER.warn("[Record] FFmpeg download from {} failed", url, e);
			}
		}
		error = "FFmpeg download failed: " + (last == null ? "unknown" : last.getMessage());
		state = State.FAILED;
	}

	private static void extract(Path zip, Path target) throws IOException {
		try (ZipInputStream zin = new ZipInputStream(Files.newInputStream(zip))) {
			ZipEntry e;
			while ((e = zin.getNextEntry()) != null) {
				if (!e.isDirectory() && e.getName().replace('\\', '/').endsWith("bin/ffmpeg.exe")) {
					try (OutputStream out = Files.newOutputStream(target)) {
						zin.transferTo(out);
					}
					return;
				}
			}
		}
		throw new IOException("bin/ffmpeg.exe not found in the download");
	}
}
