package com.sigmaxox.record.client;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.InputConstants;
import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.capture.FrameCapturer;
import com.sigmaxox.record.client.config.RecordConfig;
import com.sigmaxox.record.client.ffmpeg.FfmpegEncoder;
import com.sigmaxox.record.client.ffmpeg.FfmpegManager;
import com.sigmaxox.record.client.ffmpeg.FrameSink;
import com.sigmaxox.record.client.hw.HardwareDetect;
import com.sigmaxox.record.client.plan.RecordPlan;
import com.sigmaxox.record.client.raw.RawConverter;
import com.sigmaxox.record.client.raw.RawWriter;
import com.sigmaxox.record.client.raw.RingWriter;
import com.sigmaxox.record.client.ui.RecordUi;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;

/**
 * The recording state machine. Everything except the writer/encoder threads runs on the render thread:
 * onFrameEnd() is called once per frame, after the world, HUD and menus have been drawn.
 */
public final class Recorder {
	public static final Recorder INSTANCE = new Recorder();
	private static final long NS = 1_000_000_000L;
	/** If the game itself renders slower than ~22 fps, capture at half rate so we never add load to a struggling game. */
	private static final long SLOW_FRAME_NS = 45_000_000L;
	private static final long RECOVER_FRAME_NS = 38_000_000L;

	private boolean recording;
	private boolean replay;
	private FrameSink encoder;
	private FrameCapturer capturer;
	private long startNs;
	private long nextCaptureNs;
	private long intervalNs;
	private boolean keyWasDown;
	private boolean clipKeyWasDown;
	private long hookNsTotal;
	private long hookNsMax;
	private long hookFrames;
	private long lastFrameNs;
	private long frameEmaNs;
	private int stride = 1;

	private final List<FrameCapturer> closingCapturers = new ArrayList<>();
	private final List<FrameSink> finishingEncoders = new ArrayList<>();

	private volatile String status = "";
	private volatile boolean statusIsError;
	private volatile long statusUntilMs;

	private Recorder() {
		Runtime.getRuntime().addShutdownHook(new Thread(this::shutdown, "Record-Shutdown"));
	}

	public boolean isRecording() {
		return recording;
	}

	/** True while the replay buffer (not a normal recording) is running. */
	public boolean isReplay() {
		return recording && replay;
	}

	public long elapsedMs() {
		return recording ? (System.nanoTime() - startNs) / 1_000_000L : 0L;
	}

	/** Bytes written so far (Light) or currently buffered (Replay); shown next to the timer. */
	public long recordedBytes() {
		FrameSink e = encoder;
		return recording && e != null ? e.bytesWritten() : 0L;
	}

	public String statusText() {
		return System.currentTimeMillis() < statusUntilMs ? status : "";
	}

	public boolean statusIsError() {
		return statusIsError;
	}

	public void setStatus(String text, boolean error, long durationMs) {
		this.status = text;
		this.statusIsError = error;
		this.statusUntilMs = System.currentTimeMillis() + durationMs;
	}

	public void toggle(Minecraft mc) {
		try {
			if (recording) {
				stop();
			} else {
				start(mc);
			}
		} catch (Throwable t) {
			RecordMod.LOGGER.error("[Record] Toggle failed", t);
			setStatus("Record error: " + t.getMessage(), true, 8000);
			recording = false;
		}
		RecordUi.refreshButtons();
	}

	/** Replay mode: save the last few minutes as a clip. */
	public void saveClip() {
		if (!(recording && encoder instanceof RingWriter ring)) {
			setStatus("Save Clip works while the Replay buffer is running (set Mode: Replay, then start it).", true, 6000);
			return;
		}
		ring.requestClip(RecordConfig.get().clipSeconds);
		setStatus("Saving clip...", false, 4000);
	}

	private void start(Minecraft mc) throws Exception {
		RecordConfig cfg = RecordConfig.get();
		boolean live = cfg.mode == RecordConfig.Mode.LIVE;
		boolean isReplayMode = cfg.mode == RecordConfig.Mode.REPLAY;

		if (live) {
			switch (FfmpegManager.state()) {
				case READY -> {
				}
				case DOWNLOADING, SEARCHING, PROBING, UNKNOWN -> {
					setStatus("Preparing FFmpeg, please wait a moment and press Record again...", false, 6000);
					return;
				}
				default -> {
					// MISSING or FAILED: try to download (Windows) and tell the player.
					FfmpegManager.downloadAsync();
					if (FfmpegManager.state() == FfmpegManager.State.FAILED) {
						setStatus(FfmpegManager.error(), true, 10000);
					} else {
						setStatus("FFmpeg is missing - downloading it automatically. Press Record again when it finishes.", false, 8000);
					}
					return;
				}
			}
		}

		RenderTarget target = mc.gameRenderer.mainRenderTarget();
		HardwareDetect.Info hw = HardwareDetect.detect(mc);
		Path dir = RecordConfig.recordingsDir();
		Files.createDirectories(dir);
		String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));

		RecordPlan plan;
		FrameSink sink;
		String summary;
		if (live) {
			plan = RecordPlan.build(cfg, hw, FfmpegManager.encoders(), target.width, target.height);
			sink = new FfmpegEncoder(FfmpegManager.command(), plan, dir.resolve("record_" + stamp + ".mp4"));
			summary = plan.describeLive(cfg.targetGbPer10Min);
		} else {
			long free = Files.getFileStore(dir).getUsableSpace();
			if (free < (long) (cfg.minFreeGb * 1e9)) {
				setStatus(String.format("Not enough free disk space (%.1f GB free).", free / 1e9), true, 8000);
				return;
			}
			plan = RecordPlan.light(cfg, hw, target.width, target.height);
			if (isReplayMode) {
				sink = new RingWriter(dir, plan, (long) (cfg.bufferMinutes * 60.0 * 1e9), (long) (cfg.minFreeGb * 1e9));
				summary = plan.describeReplay(cfg.bufferMinutes);
			} else {
				sink = new RawWriter(dir.resolve("record_" + stamp + ".rawv"), plan,
					(long) (cfg.maxSizeGb * 1e9), (long) (cfg.minFreeGb * 1e9));
				summary = plan.describeLight();
			}
		}
		sink.start();
		FrameCapturer cap = new FrameCapturer(plan.width(), plan.height());

		this.encoder = sink;
		this.capturer = cap;
		this.replay = isReplayMode;
		this.intervalNs = NS / plan.fps();
		this.startNs = System.nanoTime();
		this.nextCaptureNs = startNs;
		this.hookNsTotal = 0;
		this.hookNsMax = 0;
		this.hookFrames = 0;
		this.lastFrameNs = 0;
		this.frameEmaNs = 0;
		this.stride = 1;
		this.recording = true;
		RecordMod.LOGGER.info("[Record] Started {} ({}, mode {}, tier {}, GPU {})", sink.file(), summary,
			cfg.mode, hw.tier(), hw.gpuName());
		if (isReplayMode) {
			setStatus("Replay buffer ON - press " + keyName(cfg.clipHotkey) + " to save the last "
				+ formatSeconds(cfg.clipSeconds) + ". " + summary, false, 9000);
		} else {
			setStatus((live ? "Recording: " : "Recording (light): ") + summary, false, 5000);
		}
	}

	private static String keyName(int glfwKey) {
		return switch (glfwKey) {
			case 298 -> "F9";
			case 299 -> "F10";
			case 300 -> "F11";
			case 301 -> "F12";
			default -> "the clip key";
		};
	}

	private static String formatSeconds(double seconds) {
		return seconds >= 90 ? String.format("%.0f min", seconds / 60.0) : String.format("%.0f s", seconds);
	}

	private void stop() {
		if (!recording) {
			return;
		}
		long endTs = System.nanoTime() - startNs;
		FrameSink enc = encoder;
		FrameCapturer cap = capturer;
		boolean wasReplay = replay;
		recording = false;
		replay = false;
		encoder = null;
		capturer = null;
		if (cap != null) {
			cap.requestClose();
			closingCapturers.add(cap);
			RecordMod.LOGGER.info("[Record] Captured {} frames, dropped {}. Recorder cost on the render thread: avg {} ms, max {} ms per frame",
				cap.captured(), cap.dropped(),
				String.format("%.2f", hookFrames == 0 ? 0.0 : hookNsTotal / (double) hookFrames / 1e6),
				String.format("%.2f", hookNsMax / 1e6));
		}
		if (enc != null) {
			enc.setDroppedFrames(cap == null ? 0 : cap.dropped());
			enc.finish(endTs);
			finishingEncoders.add(enc);
		}
		setStatus(wasReplay ? "Replay buffer stopped (unsaved footage was discarded)." : "Saving video...",
			false, wasReplay ? 6000 : 60000);
	}

	/** Called by GameRendererMixin at the end of every frame (render thread). */
	public void onFrameEnd(RenderTarget target) {
		Minecraft mc = Minecraft.getInstance();
		try {
			pollHotkeys(mc);
			housekeeping();
			if (!recording) {
				return;
			}
			if (encoder.hasFailed()) {
				String why = encoder.failureMessage();
				stop();
				setStatus("Recording stopped: " + why, true, 12000);
				RecordUi.refreshButtons();
				return;
			}
			String limit = encoder.limitReached();
			if (limit != null) {
				stop();
				setStatus(limit + (replay ? "" : " The recording was saved."), true, 14000);
				RecordUi.refreshButtons();
				return;
			}
			if (encoder instanceof RingWriter ring) {
				Path clip = ring.takeReadyClip();
				if (clip != null) {
					if (RecordConfig.get().autoConvert) {
						setStatus("Clip saved - converting to MP4...", false, 8000);
						RawConverter.convertPending(mc);
					} else {
						setStatus("Clip saved. Convert it later: Record settings > Convert recordings.", false, 9000);
					}
				}
				String problem = ring.takeClipProblem();
				if (problem != null) {
					setStatus(problem, true, 7000);
				}
			}

			long hookStart = System.nanoTime();
			updateFramePacing(hookStart);
			capturer.poll(encoder);

			long now = hookStart;
			long effectiveInterval = intervalNs * stride;
			if (now >= nextCaptureNs - effectiveInterval / 2) {
				if (now - nextCaptureNs > effectiveInterval) {
					nextCaptureNs = now;
				}
				if (capturer.capture(target, now - startNs)) {
					nextCaptureNs += effectiveInterval;
				}
			}
			long cost = System.nanoTime() - hookStart;
			hookNsTotal += cost;
			hookNsMax = Math.max(hookNsMax, cost);
			hookFrames++;
		} catch (Throwable t) {
			// Never let a recording problem crash the game.
			RecordMod.LOGGER.error("[Record] Error while recording, stopping", t);
			try {
				if (recording) {
					stop();
				}
			} catch (Throwable ignored) {
			}
			setStatus("Recording error: " + t.getMessage(), true, 10000);
			RecordUi.refreshButtons();
		}
	}

	/** Tracks how long the game's own frames take and halves the capture rate if the game is struggling. */
	private void updateFramePacing(long now) {
		if (lastFrameNs != 0) {
			long d = now - lastFrameNs;
			frameEmaNs = frameEmaNs == 0 ? d : (long) (frameEmaNs * 0.9 + d * 0.1);
			if (frameEmaNs > SLOW_FRAME_NS) {
				stride = 2;
			} else if (frameEmaNs < RECOVER_FRAME_NS) {
				stride = 1;
			}
		}
		lastFrameNs = now;
	}

	private void pollHotkeys(Minecraft mc) {
		RecordConfig cfg = RecordConfig.get();
		boolean down = InputConstants.isKeyDown(mc.getWindow(), cfg.hotkey);
		if (down && !keyWasDown) {
			toggle(mc);
		}
		keyWasDown = down;

		boolean clipDown = InputConstants.isKeyDown(mc.getWindow(), cfg.clipHotkey);
		if (clipDown && !clipKeyWasDown && cfg.mode == RecordConfig.Mode.REPLAY) {
			saveClip();
		}
		clipKeyWasDown = clipDown;
	}

	private void housekeeping() {
		closingCapturers.removeIf(FrameCapturer::tryFinishClose);
		for (int i = finishingEncoders.size() - 1; i >= 0; i--) {
			FrameSink e = finishingEncoders.get(i);
			if (!e.isDone()) {
				continue;
			}
			finishingEncoders.remove(i);
			if (e instanceof RingWriter) {
				if (e.hasFailed()) {
					setStatus("Replay buffer error: " + e.failureMessage(), true, 12000);
				}
				continue; // the buffer is discarded on stop; saved clips were reported when they were made
			}
			if (e.hasFailed()) {
				setStatus("Video error: " + e.failureMessage(), true, 12000);
			} else if (e.framesWritten() == 0) {
				try {
					Files.deleteIfExists(e.file());
				} catch (Exception ignored) {
				}
				setStatus("Nothing was recorded.", true, 5000);
			} else {
				String note = e.droppedFrames() > 0 ? " (" + e.droppedFrames() + " frames dropped - try a lower resolution/fps)" : "";
				if (e instanceof RawWriter) {
					String size = String.format("%.1f GB", e.bytesWritten() / 1e9);
					if (RecordConfig.get().autoConvert) {
						setStatus("Saved " + e.file().getFileName() + " (" + size + ") - converting to MP4...", false, 9000);
						RawConverter.convertPending(Minecraft.getInstance());
					} else {
						setStatus("Saved " + size + note + ". Convert it later: Record settings > Convert recordings.", false, 12000);
					}
				} else {
					setStatus("Saved: " + e.file().getFileName() + note, false, 9000);
				}
			}
		}
	}

	private void shutdown() {
		try {
			if (recording && encoder != null) {
				encoder.finish(System.nanoTime() - startNs);
				encoder.awaitDone(8000);
			}
			for (FrameSink e : finishingEncoders) {
				e.awaitDone(8000);
			}
		} catch (Throwable ignored) {
		}
	}
}
