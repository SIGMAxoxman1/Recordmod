package com.sigmaxox.record.client;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.InputConstants;
import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.capture.FrameCapturer;
import com.sigmaxox.record.client.config.RecordConfig;
import com.sigmaxox.record.client.ffmpeg.FfmpegEncoder;
import com.sigmaxox.record.client.ffmpeg.FfmpegManager;
import com.sigmaxox.record.client.hw.HardwareDetect;
import com.sigmaxox.record.client.plan.RecordPlan;
import com.sigmaxox.record.client.ui.RecordUi;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;

/**
 * The recording state machine. Everything except the encoder thread runs on the render thread:
 * onFrameEnd() is called once per frame, after the world, HUD and menus have been drawn.
 */
public final class Recorder {
	public static final Recorder INSTANCE = new Recorder();
	private static final long NS = 1_000_000_000L;

	private boolean recording;
	private FfmpegEncoder encoder;
	private FrameCapturer capturer;
	private long startNs;
	private long nextCaptureNs;
	private long intervalNs;
	private boolean keyWasDown;
	private RecordPlan activePlan;

	private final List<FrameCapturer> closingCapturers = new ArrayList<>();
	private final List<FfmpegEncoder> finishingEncoders = new ArrayList<>();

	private volatile String status = "";
	private volatile boolean statusIsError;
	private volatile long statusUntilMs;

	private Recorder() {
		Runtime.getRuntime().addShutdownHook(new Thread(this::shutdown, "Record-Shutdown"));
	}

	public boolean isRecording() {
		return recording;
	}

	public long elapsedMs() {
		return recording ? (System.nanoTime() - startNs) / 1_000_000L : 0L;
	}

	public String statusText() {
		return System.currentTimeMillis() < statusUntilMs ? status : "";
	}

	public boolean statusIsError() {
		return statusIsError;
	}

	private void setStatus(String text, boolean error, long durationMs) {
		this.status = text;
		this.statusIsError = error;
		this.statusUntilMs = System.currentTimeMillis() + durationMs;
	}

	public void toggle(Minecraft mc) {
		try {
			if (recording) {
				stop();
			} else {
				start(mc);
			}
		} catch (Throwable t) {
			RecordMod.LOGGER.error("[Record] Toggle failed", t);
			setStatus("Record error: " + t.getMessage(), true, 8000);
			recording = false;
		}
		RecordUi.refreshButtons();
	}

	private void start(Minecraft mc) throws Exception {
		switch (FfmpegManager.state()) {
			case READY -> {
			}
			case DOWNLOADING, SEARCHING, PROBING, UNKNOWN -> {
				setStatus("Preparing FFmpeg, please wait a moment and press Record again...", false, 6000);
				return;
			}
			default -> {
				// MISSING or FAILED: try to download (Windows) and tell the player.
				FfmpegManager.downloadAsync();
				if (FfmpegManager.state() == FfmpegManager.State.FAILED) {
					setStatus(FfmpegManager.error(), true, 10000);
				} else {
					setStatus("FFmpeg is missing - downloading it automatically. Press Record again when it finishes.", false, 8000);
				}
				return;
			}
		}

		RenderTarget target = mc.gameRenderer.mainRenderTarget();
		HardwareDetect.Info hw = HardwareDetect.detect(mc);
		RecordConfig cfg = RecordConfig.get();
		RecordPlan plan = RecordPlan.build(cfg, hw, FfmpegManager.encoders(), target.width, target.height);

		Path dir = cfg.outputDir.isBlank()
			? FabricLoader.getInstance().getGameDir().resolve("recordings")
			: Path.of(cfg.outputDir);
		Files.createDirectories(dir);
		String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
		Path file = dir.resolve("record_" + stamp + ".mp4");

		FfmpegEncoder enc = new FfmpegEncoder(FfmpegManager.command(), plan, file);
		enc.start();
		FrameCapturer cap = new FrameCapturer(plan.width(), plan.height());

		this.encoder = enc;
		this.capturer = cap;
		this.activePlan = plan;
		this.intervalNs = NS / plan.fps();
		this.startNs = System.nanoTime();
		this.nextCaptureNs = startNs;
		this.recording = true;
		RecordMod.LOGGER.info("[Record] Recording {} ({}, tier {}, GPU {})", file, plan.describe(), hw.tier(), hw.gpuName());
		setStatus("Recording: " + plan.describe(), false, 4000);
	}

	private void stop() {
		if (!recording) {
			return;
		}
		long endTs = System.nanoTime() - startNs;
		FfmpegEncoder enc = encoder;
		FrameCapturer cap = capturer;
		recording = false;
		encoder = null;
		capturer = null;
		if (cap != null) {
			cap.requestClose();
			closingCapturers.add(cap);
			RecordMod.LOGGER.info("[Record] Captured {} frames, dropped {}", cap.captured(), cap.dropped());
		}
		if (enc != null) {
			enc.finish(endTs);
			finishingEncoders.add(enc);
		}
		setStatus("Saving video...", false, 60000);
	}

	/** Called by GameRendererMixin at the end of every frame (render thread). */
	public void onFrameEnd(RenderTarget target) {
		Minecraft mc = Minecraft.getInstance();
		try {
			pollHotkey(mc);
			housekeeping();
			if (!recording) {
				return;
			}
			if (encoder.hasFailed()) {
				String why = encoder.failureMessage();
				stop();
				setStatus("Recording stopped: " + why, true, 12000);
				RecordUi.refreshButtons();
				return;
			}
			capturer.poll(encoder);

			long now = System.nanoTime();
			if (now >= nextCaptureNs - intervalNs / 2) {
				if (now - nextCaptureNs > intervalNs) {
					nextCaptureNs = now;
				}
				if (capturer.capture(target, now - startNs)) {
					nextCaptureNs += intervalNs;
				}
			}
		} catch (Throwable t) {
			// Never let a recording problem crash the game.
			RecordMod.LOGGER.error("[Record] Error while recording, stopping", t);
			try {
				if (recording) {
					stop();
				}
			} catch (Throwable ignored) {
			}
			setStatus("Recording error: " + t.getMessage(), true, 10000);
			RecordUi.refreshButtons();
		}
	}

	private void pollHotkey(Minecraft mc) {
		int key = RecordConfig.get().hotkey;
		boolean down = InputConstants.isKeyDown(mc.getWindow(), key);
		if (down && !keyWasDown) {
			toggle(mc);
		}
		keyWasDown = down;
	}

	private void housekeeping() {
		closingCapturers.removeIf(FrameCapturer::tryFinishClose);
		for (int i = finishingEncoders.size() - 1; i >= 0; i--) {
			FfmpegEncoder e = finishingEncoders.get(i);
			if (!e.isDone()) {
				continue;
			}
			finishingEncoders.remove(i);
			if (e.hasFailed()) {
				setStatus("Video error: " + e.failureMessage(), true, 12000);
			} else if (e.framesWritten() == 0) {
				try {
					Files.deleteIfExists(e.file());
				} catch (Exception ignored) {
				}
				setStatus("Nothing was recorded.", true, 5000);
			} else {
				setStatus("Saved: " + e.file().getFileName(), false, 7000);
			}
		}
	}

	private void shutdown() {
		try {
			if (recording && encoder != null) {
				encoder.finish(System.nanoTime() - startNs);
				encoder.awaitDone(8000);
			}
			for (FfmpegEncoder e : finishingEncoders) {
				e.awaitDone(8000);
			}
		} catch (Throwable ignored) {
		}
	}
}
