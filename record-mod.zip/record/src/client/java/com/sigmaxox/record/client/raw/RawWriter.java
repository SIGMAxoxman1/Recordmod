package com.sigmaxox.record.client.raw;

import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.ffmpeg.FrameSink;
import com.sigmaxox.record.client.plan.RecordPlan;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * "Light" mode writer: no encoder runs while you play.
 * Each frame is converted to YUV 4:2:0 (1.5 bytes/pixel instead of 4) and appended to a .rawv file.
 * Only frames the game really rendered are stored (no duplicates), each with its timestamp, so the
 * file is as small as possible. FFmpeg turns it into an MP4 later (see RawConverter).
 *
 * File format: "RECRAW01", int width, int height, int fps, then repeated [long tsNs][I420 frame].
 * It is valid at any point, so a crash never loses the recording.
 */
public final class RawWriter implements FrameSink {
	public static final byte[] MAGIC = "RECRAW01".getBytes(StandardCharsets.US_ASCII);
	public static final int HEADER_BYTES = 8 + 12;

	private final Path file;
	private final RecordPlan plan;
	private final long rgbaBytes;
	private final int i420Bytes;
	private final int maxBuffers;
	private final long maxFileBytes;
	private final long minFreeBytes;
	private final BlockingQueue<Frame> queue;
	private final BlockingQueue<byte[]> freeBuffers;
	private final AtomicInteger allocated = new AtomicInteger();

	private DataOutputStream out;
	private Thread thread;
	private volatile boolean finishRequested;
	private volatile boolean done;
	private volatile boolean failed;
	private volatile String failure = "";
	private volatile String limit;
	private volatile long bytesWritten;
	private volatile long frames;
	private volatile long dropped;

	public RawWriter(Path file, RecordPlan plan, long maxFileBytes, long minFreeBytes) {
		this.file = file;
		this.plan = plan;
		this.rgbaBytes = (long) plan.width() * plan.height() * 4L;
		this.i420Bytes = Yuv.i420Size(plan.width(), plan.height());
		this.maxBuffers = (int) Math.max(8, Math.min(24, (160L * 1024 * 1024) / Math.max(1, rgbaBytes)));
		this.maxFileBytes = maxFileBytes;
		this.minFreeBytes = minFreeBytes;
		this.queue = new ArrayBlockingQueue<>(maxBuffers);
		this.freeBuffers = new ArrayBlockingQueue<>(maxBuffers);
	}

	@Override
	public void start() throws IOException {
		Files.createDirectories(file.toAbsolutePath().getParent());
		out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(file), 4 << 20));
		out.write(MAGIC);
		out.writeInt(plan.width());
		out.writeInt(plan.height());
		out.writeInt(plan.fps());
		bytesWritten = HEADER_BYTES;
		thread = new Thread(this::run, "Record-RawWriter");
		thread.setDaemon(true);
		thread.start();
	}

	@Override
	public byte[] acquire() {
		byte[] b = freeBuffers.poll();
		if (b == null && allocated.get() < maxBuffers) {
			allocated.incrementAndGet();
			b = new byte[(int) rgbaBytes];
		}
		return b;
	}

	@Override
	public void release(byte[] buffer) {
		freeBuffers.offer(buffer);
	}

	@Override
	public boolean offer(Frame frame) {
		return !failed && !finishRequested && queue.offer(frame);
	}

	@Override
	public void finish(long endTsNs) {
		finishRequested = true;
	}

	private void run() {
		byte[] i420 = new byte[i420Bytes];
		try {
			while (true) {
				Frame f = queue.poll(50, TimeUnit.MILLISECONDS);
				if (f == null) {
					if (failed || (finishRequested && queue.isEmpty())) {
						break;
					}
					continue;
				}
				try {
					if (!failed) {
						Yuv.rgbaBottomUpToI420(f.data(), plan.width(), plan.height(), i420);
						out.writeLong(f.tsNs());
						out.write(i420, 0, i420Bytes);
						bytesWritten += 8L + i420Bytes;
						frames++;
						if ((frames & 31L) == 0L) {
							checkLimits();
						}
					}
				} catch (IOException e) {
					failed = true;
					failure = "Could not write the recording: " + e.getMessage();
					RecordMod.LOGGER.error("[Record] {}", failure);
				} finally {
					release(f.data());
				}
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		} finally {
			try {
				if (out != null) {
					out.close();
				}
			} catch (IOException e) {
				if (!failed) {
					failed = true;
					failure = "Could not finish the file: " + e.getMessage();
				}
			}
			done = true;
		}
	}

	private void checkLimits() {
		if (limit != null) {
			return;
		}
		if (bytesWritten >= maxFileBytes) {
			limit = String.format("Stopped: size limit reached (%.0f GB).", maxFileBytes / 1e9);
			return;
		}
		try {
			if (Files.getFileStore(file.toAbsolutePath()).getUsableSpace() < minFreeBytes) {
				limit = "Stopped: disk space is almost full.";
			}
		} catch (IOException ignored) {
		}
	}

	@Override
	public boolean isDone() {
		return done;
	}

	@Override
	public boolean hasFailed() {
		return failed;
	}

	@Override
	public String failureMessage() {
		return failure;
	}

	@Override
	public long framesWritten() {
		return frames;
	}

	@Override
	public Path file() {
		return file;
	}

	@Override
	public boolean awaitDone(long timeoutMs) {
		long end = System.currentTimeMillis() + timeoutMs;
		while (!done && System.currentTimeMillis() < end) {
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				break;
			}
		}
		return done;
	}

	@Override
	public long droppedFrames() {
		return dropped;
	}

	@Override
	public void setDroppedFrames(long dropped) {
		this.dropped = dropped;
	}

	@Override
	public String limitReached() {
		return limit;
	}

	@Override
	public long bytesWritten() {
		return bytesWritten;
	}
}
