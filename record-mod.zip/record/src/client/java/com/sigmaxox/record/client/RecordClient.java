package com.sigmaxox.record.client;

import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.config.RecordConfig;
import com.sigmaxox.record.client.replaymod.ReplayModBridge;
import net.fabricmc.api.ClientModInitializer;

public class RecordClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		RecordConfig.get();
		if (ReplayModBridge.available()) {
			RecordMod.LOGGER.info("[Record] ReplayMod found - recording the exact camera of every frame next to its recordings.");
		} else {
			RecordMod.LOGGER.info("[Record] ReplayMod is not available ({}). This mod does nothing without it.", ReplayModBridge.problem());
		}
	}
}
