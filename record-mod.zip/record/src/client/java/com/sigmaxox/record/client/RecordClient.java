package com.sigmaxox.record.client;

import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.config.RecordConfig;
import com.sigmaxox.record.client.ffmpeg.FfmpegManager;
import net.fabricmc.api.ClientModInitializer;

public class RecordClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		RecordConfig.get();
		FfmpegManager.init();
		RecordMod.LOGGER.info("[Record] Client initialised. Press F9 or use the Record button to start/stop recording.");
	}
}
