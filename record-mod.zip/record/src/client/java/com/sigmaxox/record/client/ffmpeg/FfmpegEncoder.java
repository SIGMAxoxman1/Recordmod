package com.sigmaxox.record.client.ffmpeg;

import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.config.RecordConfig.Encoder;
import com.sigmaxox.record.client.hw.HardwareDetect.Tier;
import com.sigmaxox.record.client.plan.RecordPlan;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Pipes raw RGBA frames into an external FFmpeg process on its own thread.
 * Frames carry a timestamp; the writer repeats frames so the video has a constant frame rate
 * and matches real time, even when the game runs slower or faster than the target fps.
 */
public final class FfmpegEncoder {
	private static final long NS = 1_000_000_000L;

	/** One captured frame (RGBA, rows bottom-to-top, like the GPU stores it). */
	public record Frame(byte[] data, long tsNs) {
	}

	private final RecordPlan plan;
	private final Path file;
	private final List<String> command;
	private final long frameBytes;
	private final int maxBuffers;
	private final BlockingQueue<Frame> queue;
	private final BlockingQueue<byte[]> freeBuffers;
	private final AtomicInteger allocated = new AtomicInteger();
	private final Deque<String> logTail = new ArrayDeque<>();

	private Process process;
	private OutputStream out;
	private Thread thread;
	private volatile boolean finishRequested;
	private volatile long endTsNs;
	private volatile boolean done;
	private volatile boolean failed;
	private volatile String failure = "";
	private long framesWritten;

	public FfmpegEncoder(String ffmpeg, RecordPlan plan, Path file) {
		this.plan = plan;
		this.file = file;
		this.frameBytes = (long) plan.width() * plan.height() * 4L;
		this.maxBuffers = (int) Math.max(4, Math.min(12, (256L * 1024 * 1024) / Math.max(1, frameBytes)));
		this.queue = new ArrayBlockingQueue<>(maxBuffers);
		this.freeBuffers = new ArrayBlockingQueue<>(maxBuffers);
		this.command = buildCommand(ffmpeg, plan, file);
	}

	public Path file() {
		return file;
	}

	public boolean isDone() {
		return done;
	}

	public boolean hasFailed() {
		return failed;
	}

	public String failureMessage() {
		return failure;
	}

	public long framesWritten() {
		return framesWritten;
	}

	public void start() throws IOException {
		Files.createDirectories(file.toAbsolutePath().getParent());
		RecordMod.LOGGER.info("[Record] Starting FFmpeg: {}", String.join(" ", command));
		process = new ProcessBuilder(command).redirectErrorStream(true).start();
		out = new BufferedOutputStream(process.getOutputStream(), 1 << 20);

		Thread logger = new Thread(() -> {
			try (BufferedReader r = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(process.getInputStream()), StandardCharsets.UTF_8))) {
				String line;
				while ((line = r.readLine()) != null) {
					synchronized (logTail) {
						logTail.addLast(line);
						while (logTail.size() > 12) {
							logTail.removeFirst();
						}
					}
				}
			} catch (IOException ignored) {
			}
		}, "Record-FFmpeg-Log");
		logger.setDaemon(true);
		logger.start();

		thread = new Thread(this::run, "Record-Encoder");
		thread.setDaemon(true);
		thread.start();
	}

	/** Non-blocking: returns a free frame buffer or null if the encoder is behind (frame gets dropped). */
	public byte[] acquire() {
		byte[] b = freeBuffers.poll();
		if (b == null && allocated.get() < maxBuffers) {
			allocated.incrementAndGet();
			b = new byte[(int) frameBytes];
		}
		return b;
	}

	public void release(byte[] buffer) {
		freeBuffers.offer(buffer);
	}

	/** Non-blocking. Returns false if the queue is full (caller must release the buffer). */
	public boolean offer(Frame frame) {
		return !failed && !finishRequested && queue.offer(frame);
	}

	/** Tells the encoder that recording ended at the given time; it finishes the file on its own thread. */
	public void finish(long endTsNs) {
		this.endTsNs = endTsNs;
		this.finishRequested = true;
	}

	public boolean awaitDone(long timeoutMs) {
		long end = System.currentTimeMillis() + timeoutMs;
		while (!done && System.currentTimeMillis() < end) {
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				break;
			}
		}
		return done;
	}

	private void run() {
		byte[] last = null;
		try {
			while (true) {
				Frame f = queue.poll(50, TimeUnit.MILLISECONDS);
				if (f == null) {
					if (failed || (finishRequested && queue.isEmpty())) {
						break;
					}
					continue;
				}
				if (failed) {
					release(f.data());
					continue;
				}
				if (last == null) {
					last = f.data();
				} else {
					long due = f.tsNs() * plan.fps() / NS;
					writeRepeated(last, due - framesWritten);
					release(last);
					last = f.data();
				}
			}
			if (last != null && !failed) {
				long due = Math.max(framesWritten + 1, endTsNs * plan.fps() / NS);
				writeRepeated(last, due - framesWritten);
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		} finally {
			closeProcess();
			done = true;
		}
	}

	private void writeRepeated(byte[] data, long count) {
		for (long i = 0; i < count && !failed; i++) {
			try {
				out.write(data, 0, (int) frameBytes);
				framesWritten++;
			} catch (IOException e) {
				fail(e);
			}
		}
	}

	private void fail(Exception e) {
		failed = true;
		failure = describeFailure(e);
		RecordMod.LOGGER.error("[Record] FFmpeg stopped: {}", failure);
	}

	private String describeFailure(Exception e) {
		String tail;
		synchronized (logTail) {
			tail = String.join(" | ", logTail);
		}
		return tail.isBlank() ? String.valueOf(e.getMessage()) : tail;
	}

	private void closeProcess() {
		try {
			if (out != null) {
				out.close();
			}
		} catch (IOException ignored) {
		}
		try {
			if (process != null && !process.waitFor(30, TimeUnit.SECONDS)) {
				process.destroyForcibly();
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			if (process != null) {
				process.destroyForcibly();
			}
		}
		if (!failed && process != null && process.exitValue() != 0) {
			failed = true;
			failure = describeFailure(new IOException("FFmpeg exit code " + process.exitValue()));
		}
	}

	static List<String> buildCommand(String ffmpeg, RecordPlan p, Path file) {
		int q = switch (p.quality()) {
			case LOW -> 28;
			case HIGH -> 19;
			default -> 23;
		};
		String pix = p.encoder() == Encoder.QSV ? "nv12" : "yuv420p";
		List<String> c = new ArrayList<>(List.of(
			ffmpeg, "-y", "-hide_banner", "-loglevel", "warning",
			"-f", "rawvideo", "-pix_fmt", "rgba",
			"-s", p.width() + "x" + p.height(),
			"-framerate", String.valueOf(p.fps()),
			"-i", "pipe:0",
			// GPU rows are bottom-to-top, so flip; convert RGB -> YUV with the HD (bt709) matrix.
			"-vf", "vflip,scale=out_color_matrix=bt709:out_range=tv,format=" + pix
		));
		switch (p.encoder()) {
			case NVENC -> c.addAll(List.of("-c:v", "h264_nvenc", "-preset", "p4", "-rc", "vbr",
				"-cq", String.valueOf(q), "-b:v", "0"));
			case AMF -> c.addAll(List.of("-c:v", "h264_amf", "-quality", "balanced", "-rc", "cqp",
				"-qp_i", String.valueOf(q), "-qp_p", String.valueOf(q), "-qp_b", String.valueOf(q)));
			case QSV -> c.addAll(List.of("-c:v", "h264_qsv", "-preset", "veryfast",
				"-global_quality", String.valueOf(q)));
			default -> {
				Tier t = p.hw().tier();
				String preset = t == Tier.STRONG ? "veryfast" : t == Tier.MEDIUM ? "superfast" : "ultrafast";
				c.addAll(List.of("-c:v", "libx264", "-preset", preset, "-tune", "zerolatency", "-crf", String.valueOf(q)));
			}
		}
		c.addAll(List.of(
			"-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709",
			"-g", String.valueOf(p.fps() * 2),
			// Fragmented MP4: the file stays playable even if the game crashes mid-recording.
			"-movflags", "+frag_keyframe+empty_moov+default_base_moof",
			file.toAbsolutePath().toString()
		));
		return c;
	}
}
