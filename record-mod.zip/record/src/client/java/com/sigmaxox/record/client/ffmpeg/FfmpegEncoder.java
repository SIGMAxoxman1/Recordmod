package com.sigmaxox.record.client.ffmpeg;

import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.config.RecordConfig;
import com.sigmaxox.record.client.config.RecordConfig.Encoder;
import com.sigmaxox.record.client.hw.HardwareDetect.Tier;
import com.sigmaxox.record.client.plan.RecordPlan;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.ProcessBuilder.Redirect;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Pipes raw frames into an external FFmpeg process on its own thread.
 * Frames carry a timestamp; the writer repeats frames so the video has a constant frame rate
 * and matches real time, even when the game runs slower or faster than the target fps.
 *
 * Two uses:
 *  - Live mode: input is RGBA from the GPU (flipped + converted by FFmpeg), tuned to be light on the PC.
 *  - Light mode conversion ("offline"): input is I420 read from a .rawv file, tuned for quality/speed.
 */
public final class FfmpegEncoder implements FrameSink {
	private static final long NS = 1_000_000_000L;

	private final RecordPlan plan;
	private final Path file;
	private final boolean yuvInput;
	private final boolean offline;
	private final List<String> command;
	private final long inputBytes;
	private final int maxBuffers;
	private final BlockingQueue<Frame> queue;
	private final BlockingQueue<byte[]> freeBuffers;
	private final AtomicInteger allocated = new AtomicInteger();
	private final Deque<String> logTail = new ArrayDeque<>();

	private Process process;
	private OutputStream out;
	private Thread thread;
	private volatile boolean finishRequested;
	private volatile long endTsNs;
	private volatile boolean done;
	private volatile boolean failed;
	private volatile String failure = "";
	private long framesWritten;
	private volatile long droppedFrames;

	public FfmpegEncoder(String ffmpeg, RecordPlan plan, Path file) {
		this(ffmpeg, plan, file, false, false);
	}

	public FfmpegEncoder(String ffmpeg, RecordPlan plan, Path file, boolean yuvInput, boolean offline) {
		this.plan = plan;
		this.file = file;
		this.yuvInput = yuvInput;
		this.offline = offline;
		long pixels = (long) plan.width() * plan.height();
		this.inputBytes = yuvInput ? pixels * 3L / 2L : pixels * 4L;
		this.maxBuffers = (int) Math.max(4, Math.min(12, (256L * 1024 * 1024) / Math.max(1, inputBytes)));
		this.queue = new ArrayBlockingQueue<>(maxBuffers);
		this.freeBuffers = new ArrayBlockingQueue<>(maxBuffers);
		this.command = buildCommand(ffmpeg, plan, file, yuvInput, offline, targetKbps(RecordConfig.get().targetGbPer10Min));
	}

	@Override
	public Path file() {
		return file;
	}

	@Override
	public boolean isDone() {
		return done;
	}

	@Override
	public boolean hasFailed() {
		return failed;
	}

	@Override
	public String failureMessage() {
		return failure;
	}

	@Override
	public long droppedFrames() {
		return droppedFrames;
	}

	@Override
	public void setDroppedFrames(long dropped) {
		this.droppedFrames = dropped;
	}

	@Override
	public long framesWritten() {
		return framesWritten;
	}

	@Override
	public void start() throws IOException {
		Files.createDirectories(file.toAbsolutePath().getParent());
		RecordMod.LOGGER.info("[Record] Starting FFmpeg: {}", String.join(" ", command));
		process = new ProcessBuilder(command).redirectErrorStream(true).start();
		out = new BufferedOutputStream(process.getOutputStream(), 1 << 20);
		lowerPriorityAsync(process.pid());

		Thread logger = new Thread(() -> {
			try (BufferedReader r = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(process.getInputStream()), StandardCharsets.UTF_8))) {
				String line;
				while ((line = r.readLine()) != null) {
					synchronized (logTail) {
						logTail.addLast(line);
						while (logTail.size() > 12) {
							logTail.removeFirst();
						}
					}
				}
			} catch (IOException ignored) {
			}
		}, "Record-FFmpeg-Log");
		logger.setDaemon(true);
		logger.start();

		thread = new Thread(this::run, "Record-Encoder");
		thread.setDaemon(true);
		thread.start();
	}

	/** Runs FFmpeg below the game's priority so it takes CPU time only when the game doesn't need it. */
	private static void lowerPriorityAsync(long pid) {
		Thread t = new Thread(() -> {
			try {
				boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win");
				List<String> cmd = windows
					? List.of("powershell", "-NoProfile", "-NonInteractive", "-Command",
						"(Get-Process -Id " + pid + ").PriorityClass='BelowNormal'")
					: List.of("renice", "-n", "10", "-p", String.valueOf(pid));
				Process p = new ProcessBuilder(cmd).redirectErrorStream(true).redirectOutput(Redirect.DISCARD).start();
				p.waitFor(10, TimeUnit.SECONDS);
			} catch (Exception ignored) {
			}
		}, "Record-Priority");
		t.setDaemon(true);
		t.start();
	}

	/** Non-blocking: returns a free frame buffer or null if the encoder is behind (frame gets dropped). */
	@Override
	public byte[] acquire() {
		byte[] b = freeBuffers.poll();
		if (b == null && allocated.get() < maxBuffers) {
			allocated.incrementAndGet();
			b = new byte[(int) inputBytes];
		}
		return b;
	}

	@Override
	public void release(byte[] buffer) {
		freeBuffers.offer(buffer);
	}

	/** Non-blocking. Returns false if the queue is full (caller must release the buffer). */
	@Override
	public boolean offer(Frame frame) {
		return !failed && !finishRequested && queue.offer(frame);
	}

	/** Tells the encoder that recording ended at the given time; it finishes the file on its own thread. */
	@Override
	public void finish(long endTsNs) {
		this.endTsNs = endTsNs;
		this.finishRequested = true;
	}

	@Override
	public boolean awaitDone(long timeoutMs) {
		long end = System.currentTimeMillis() + timeoutMs;
		while (!done && System.currentTimeMillis() < end) {
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				break;
			}
		}
		return done;
	}

	private void run() {
		byte[] last = null;
		try {
			while (true) {
				Frame f = queue.poll(50, TimeUnit.MILLISECONDS);
				if (f == null) {
					if (failed || (finishRequested && queue.isEmpty())) {
						break;
					}
					continue;
				}
				if (failed) {
					release(f.data());
					continue;
				}
				if (last == null) {
					last = f.data();
				} else {
					long due = f.tsNs() * plan.fps() / NS;
					writeRepeated(last, due - framesWritten);
					release(last);
					last = f.data();
				}
			}
			if (last != null && !failed) {
				long due = Math.max(framesWritten + 1, endTsNs * plan.fps() / NS);
				writeRepeated(last, due - framesWritten);
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		} finally {
			closeProcess();
			done = true;
		}
	}

	private void writeRepeated(byte[] data, long count) {
		for (long i = 0; i < count && !failed; i++) {
			try {
				out.write(data, 0, (int) inputBytes);
				framesWritten++;
			} catch (IOException e) {
				fail(e);
			}
		}
	}

	private void fail(Exception e) {
		failed = true;
		failure = describeFailure(e);
		RecordMod.LOGGER.error("[Record] FFmpeg stopped: {}", failure);
	}

	private String describeFailure(Exception e) {
		String tail;
		synchronized (logTail) {
			tail = String.join(" | ", logTail);
		}
		return tail.isBlank() ? String.valueOf(e.getMessage()) : tail;
	}

	private void closeProcess() {
		try {
			if (out != null) {
				out.close();
			}
		} catch (IOException ignored) {
		}
		try {
			if (process != null && !process.waitFor(offline ? 300 : 30, TimeUnit.SECONDS)) {
				process.destroyForcibly();
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			if (process != null) {
				process.destroyForcibly();
			}
		}
		if (!failed && process != null && !process.isAlive() && process.exitValue() != 0) {
			failed = true;
			failure = describeFailure(new IOException("FFmpeg exit code " + process.exitValue()));
		}
	}

	/** Bitrate (kbit/s) that gives about {@code gbPer10Min} GB per 10 minutes, with 7% headroom; 0 = quality mode. */
	static int targetKbps(double gbPer10Min) {
		if (gbPer10Min <= 0) {
			return 0;
		}
		return (int) Math.max(1500, gbPer10Min * 8e9 / 600.0 / 1000.0 * 0.93);
	}

	private static List<String> concat(List<String> a, List<String> b) {
		List<String> r = new ArrayList<>(a);
		r.addAll(b);
		return r;
	}

	private static List<String> bitrate(int kbps) {
		return List.of("-b:v", kbps + "k", "-maxrate", (kbps * 5 / 4) + "k", "-bufsize", (kbps * 2) + "k");
	}

	static List<String> buildCommand(String ffmpeg, RecordPlan p, Path file, boolean yuvInput, boolean offline, int kbps) {
		int q = switch (p.quality()) {
			case LOW -> 28;
			case HIGH -> 19;
			default -> 23;
		};
		String pix = p.encoder() == Encoder.QSV ? "nv12" : "yuv420p";
		List<String> c = new ArrayList<>(List.of(ffmpeg, "-y", "-hide_banner", "-loglevel", "warning"));
		if (!offline && FfmpegManager.filterThreadsSupported()) {
			// Live mode: keep the colour conversion from grabbing every CPU core the game needs.
			c.addAll(List.of("-filter_threads", "2"));
		}
		c.addAll(List.of(
			"-f", "rawvideo", "-pix_fmt", yuvInput ? "yuv420p" : "rgba",
			"-s", p.width() + "x" + p.height(),
			"-framerate", String.valueOf(p.fps()),
			"-i", "pipe:0"
		));
		if (yuvInput) {
			// Already top-down, BT.709, 4:2:0: only QuickSync wants a different layout.
			if (p.encoder() == Encoder.QSV) {
				c.addAll(List.of("-vf", "format=nv12"));
			}
		} else {
			// GPU rows are bottom-to-top, so flip; convert RGB -> YUV with the HD (bt709) matrix.
			c.addAll(List.of("-vf", "vflip,scale=out_color_matrix=bt709:out_range=tv,format=" + pix));
		}
		switch (p.encoder()) {
			case NVENC -> {
				c.addAll(List.of("-c:v", "h264_nvenc",
					"-preset", offline ? "p5" : (p.hw().tier() == Tier.WEAK ? "p2" : "p4"), "-rc", "vbr"));
				c.addAll(kbps > 0 ? bitrate(kbps) : List.of("-cq", String.valueOf(q), "-b:v", "0"));
			}
			case AMF -> {
				c.addAll(List.of("-c:v", "h264_amf", "-quality", "balanced"));
				c.addAll(kbps > 0
					? concat(List.of("-rc", "vbr_peak"), bitrate(kbps))
					: List.of("-rc", "cqp", "-qp_i", String.valueOf(q), "-qp_p", String.valueOf(q), "-qp_b", String.valueOf(q)));
			}
			case QSV -> {
				c.addAll(List.of("-c:v", "h264_qsv", "-preset", "veryfast"));
				c.addAll(kbps > 0 ? bitrate(kbps) : List.of("-global_quality", String.valueOf(q)));
			}
			default -> {
				String preset;
				if (offline) {
					preset = "veryfast";
					c.addAll(List.of("-c:v", "libx264", "-preset", preset));
				} else {
					Tier t = p.hw().tier();
					preset = t == Tier.STRONG ? "veryfast" : t == Tier.MEDIUM ? "superfast" : "ultrafast";
					c.addAll(List.of("-c:v", "libx264", "-preset", preset, "-tune", "zerolatency",
						"-threads", String.valueOf(Math.max(2, p.hw().cpuCores() / 3))));
				}
				c.addAll(kbps > 0 ? bitrate(kbps) : List.of("-crf", String.valueOf(q)));
			}
		}
		c.addAll(List.of(
			"-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv",
			"-g", String.valueOf(p.fps() * 2)));
		if (offline) {
			c.addAll(List.of("-movflags", "+faststart"));
		} else {
			// Fragmented MP4: the file stays playable even if the game crashes mid-recording.
			c.addAll(List.of("-movflags", "+frag_keyframe+empty_moov+default_base_moof"));
		}
		c.add(file.toAbsolutePath().toString());
		return c;
	}
}
