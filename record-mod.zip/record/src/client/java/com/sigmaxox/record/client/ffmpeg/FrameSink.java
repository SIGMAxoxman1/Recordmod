package com.sigmaxox.record.client.ffmpeg;

import java.nio.file.Path;

/** Where captured frames go: the live FFmpeg encoder, or the raw-file writer of "Light" mode. */
public interface FrameSink {
	/** One captured frame (RGBA, rows bottom-to-top, like the GPU stores it) with its time since the start. */
	record Frame(byte[] data, long tsNs) {
	}

	void start() throws java.io.IOException;

	/** Non-blocking: a free RGBA frame buffer, or null if the sink is behind (the frame gets dropped). */
	byte[] acquire();

	void release(byte[] buffer);

	/** Non-blocking. False if the queue is full (the caller must release the buffer). */
	boolean offer(Frame frame);

	/** Recording ended at this time; the sink finishes its file on its own thread. */
	void finish(long endTsNs);

	boolean isDone();

	boolean hasFailed();

	String failureMessage();

	/** Number of distinct frames written. */
	long framesWritten();

	Path file();

	boolean awaitDone(long timeoutMs);

	long droppedFrames();

	void setDroppedFrames(long dropped);

	/** Non-null when a size / disk limit was reached and the recording should stop. */
	default String limitReached() {
		return null;
	}

	/** Bytes written so far (for the on-screen size readout). */
	default long bytesWritten() {
		return 0L;
	}
}
