package com.sigmaxox.record.client.ui;

import com.sigmaxox.record.client.Recorder;
import com.sigmaxox.record.client.config.RecordConfig;
import com.sigmaxox.record.client.ffmpeg.FfmpegManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Draws the REC dot + timer and status messages in the top-right corner. */
public final class RecIndicator {
	private RecIndicator() {
	}

	public static void draw(GuiGraphicsExtractor g, Minecraft mc) {
		Recorder rec = Recorder.INSTANCE;
		int width = mc.getWindow().getGuiScaledWidth();
		int y = 6;

		if (rec.isRecording() && RecordConfig.get().showIndicator) {
			long s = rec.elapsedMs() / 1000L;
			String text = s >= 3600
				? String.format("REC %d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
				: String.format("REC %02d:%02d", s / 60, s % 60);
			int x = width - mc.font.width(text) - 8;
			if ((System.currentTimeMillis() / 500L) % 2L == 0L) {
				g.fill(x - 10, y + 1, x - 4, y + 7, 0xFFE02020);
			}
			g.text(mc.font, text, x, y, 0xFFFFFFFF, true);
			y += 12;
		}

		if (FfmpegManager.state() == FfmpegManager.State.DOWNLOADING) {
			line(g, mc, width, y, "Downloading FFmpeg... " + FfmpegManager.progress() + "%", 0xFFFFE066);
			y += 12;
		}

		String status = rec.statusText();
		if (!status.isEmpty()) {
			line(g, mc, width, y, status, rec.statusIsError() ? 0xFFFF6B6B : 0xFFB8FFB8);
		}
	}

	private static void line(GuiGraphicsExtractor g, Minecraft mc, int width, int y, String text, int color) {
		int maxWidth = Math.max(80, width - 16);
		String shown = text;
		while (shown.length() > 4 && mc.font.width(shown) > maxWidth) {
			shown = shown.substring(0, shown.length() - 4) + "...";
		}
		g.text(mc.font, shown, width - mc.font.width(shown) - 8, y, color, true);
	}
}
