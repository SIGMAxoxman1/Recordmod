package com.sigmaxox.record.client.ui;

import com.sigmaxox.record.client.Notify;
import com.sigmaxox.record.client.replaymod.ReplayModBridge;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Top-right corner: a REC dot while ReplayMod records, and the latest status line. */
public final class RecIndicator {
	private RecIndicator() {
	}

	public static void draw(GuiGraphicsExtractor g, Minecraft mc) {
		int width = mc.getWindow().getGuiScaledWidth();
		int y = 6;
		long start = mc.level != null ? ReplayModBridge.recordingStart() : -1;
		if (start >= 0) {
			long s = Math.max(0, System.currentTimeMillis() - start - ReplayModBridge.recordingPausedMs()) / 1000L;
			String text = s >= 3600
				? String.format("REC %d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
				: String.format("REC %02d:%02d", s / 60, s % 60);
			int x = width - mc.font.width(text) - 8;
			if ((System.currentTimeMillis() / 500L) % 2L == 0L) {
				g.fill(x - 10, y + 1, x - 4, y + 7, 0xFFE02020);
			}
			g.text(mc.font, text, x, y, 0xFFFFFFFF, true);
			y += 12;
		}
		String status = Notify.statusText();
		if (!status.isEmpty()) {
			String shown = status;
			int max = Math.max(80, width - 16);
			while (shown.length() > 4 && mc.font.width(shown) > max) {
				shown = shown.substring(0, shown.length() - 4) + "...";
			}
			g.text(mc.font, shown, width - mc.font.width(shown) - 8, y, Notify.statusIsError() ? 0xFFFF6B6B : 0xFFB8FFB8, true);
		}
	}
}
