package com.sigmaxox.record.client.plan;

import com.sigmaxox.record.client.config.RecordConfig;
import com.sigmaxox.record.client.config.RecordConfig.Encoder;
import com.sigmaxox.record.client.config.RecordConfig.Quality;
import com.sigmaxox.record.client.hw.HardwareDetect;
import com.sigmaxox.record.client.hw.HardwareDetect.Tier;
import java.util.List;
import java.util.Set;

/** The concrete recording settings that "Auto" resolves to for this machine. */
public record RecordPlan(int width, int height, int fps, Encoder encoder, Quality quality, HardwareDetect.Info hw) {

	public static RecordPlan build(RecordConfig cfg, HardwareDetect.Info hw, Set<Encoder> available, int srcW, int srcH) {
		Encoder enc = pickEncoder(cfg, hw, available);
		boolean hardware = enc != Encoder.X264;
		Tier tier = hw.tier();

		Quality quality = cfg.quality;
		if (quality == Quality.AUTO) {
			quality = tier == Tier.STRONG ? Quality.HIGH : Quality.MEDIUM;
		}

		int fps;
		if (cfg.fps != RecordConfig.Fps.AUTO) {
			fps = cfg.fps.value;
		} else {
			int cap = (tier == Tier.WEAK || (!hardware && tier != Tier.STRONG)) ? 30 : 60;
			fps = Math.min(cap, Math.max(30, hw.refreshHz()));
		}

		int targetH;
		switch (cfg.resolution) {
			case NATIVE -> targetH = srcH;
			case P75 -> targetH = Math.round(srcH * 0.75f);
			case P50 -> targetH = Math.round(srcH * 0.5f);
			case H1080 -> targetH = Math.min(1080, srcH);
			case H720 -> targetH = Math.min(720, srcH);
			case H480 -> targetH = Math.min(480, srcH);
			default -> {
				int cap;
				if (tier == Tier.STRONG) cap = hardware ? 1440 : 1080;
				else if (tier == Tier.MEDIUM) cap = hardware ? 1080 : 720;
				else cap = hardware ? 720 : 480;
				targetH = Math.min(cap, srcH);
			}
		}
		targetH = Math.max(2, targetH);
		int targetW = Math.max(2, Math.round(targetH * (srcW / (float) Math.max(1, srcH))));
		return new RecordPlan(even(targetW), even(targetH), fps, enc, quality, hw);
	}

	/** Light mode: raw YUV frames on disk. Auto picks the biggest picture that fits the disk budget. */
	public static RecordPlan light(RecordConfig cfg, HardwareDetect.Info hw, int srcW, int srcH) {
		int fps = cfg.fps != RecordConfig.Fps.AUTO ? cfg.fps.value : 30;
		float aspect = srcW / (float) Math.max(1, srcH);
		int targetH;
		switch (cfg.resolution) {
			case NATIVE -> targetH = srcH;
			case P75 -> targetH = Math.round(srcH * 0.75f);
			case P50 -> targetH = Math.round(srcH * 0.5f);
			case H1080 -> targetH = Math.min(1080, srcH);
			case H720 -> targetH = Math.min(720, srcH);
			case H480 -> targetH = Math.min(480, srcH);
			default -> {
				targetH = 360;
				for (int candidate : new int[] {1080, 900, 720, 540, 480}) {
					if (candidate > srcH) {
						continue;
					}
					int w = even(Math.round(candidate * aspect));
					double gb = (double) w * even(candidate) * 1.5 * fps * 600.0 / 1e9;
					if (gb <= cfg.budgetGbPer10Min) {
						targetH = candidate;
						break;
					}
				}
				targetH = Math.min(targetH, srcH);
			}
		}
		targetH = Math.max(2, targetH);
		int targetW = Math.max(2, Math.round(targetH * aspect));
		return new RecordPlan(even(targetW), even(targetH), fps, Encoder.AUTO, Quality.AUTO, hw);
	}

	/** Raw YUV 4:2:0 size for 10 minutes at the plan's frame rate (an upper bound: unchanged frames are not stored twice). */
	public double estimateGbPer10Min() {
		return (double) width * height * 1.5 * fps * 600.0 / 1e9;
	}

	public String describeLive(double targetGbPer10Min) {
		String size = targetGbPer10Min > 0
			? "about " + String.format("%.1f", targetGbPer10Min) + " GB per 10 min"
			: quality.label + " quality";
		return width + "x" + height + " @ " + fps + " fps - " + encoder.label + " - " + size;
	}

	public String describeReplay(double minutes) {
		return width + "x" + height + " @ " + fps + " fps - the buffer (last "
			+ String.format("%.0f", minutes) + " min) uses about "
			+ String.format("%.1f", estimateGbPer10Min() * minutes / 10.0) + " GB, never more";
	}

	public String describeLight() {
		return width + "x" + height + " @ " + fps + " fps - about "
			+ String.format("%.1f", estimateGbPer10Min()) + " GB per 10 min (converted to MP4 later)";
	}

	private static int even(int v) {
		return Math.max(2, v & ~1);
	}

	public static Encoder pickEncoder(RecordConfig cfg, HardwareDetect.Info hw, Set<Encoder> available) {
		if (cfg.encoder != Encoder.AUTO && available.contains(cfg.encoder)) {
			return cfg.encoder;
		}
		String vendor = (hw.gpuVendor() + " " + hw.gpuName()).toLowerCase();
		Encoder preferred = null;
		if (vendor.contains("nvidia")) preferred = Encoder.NVENC;
		else if (vendor.contains("amd") || vendor.contains("radeon") || vendor.contains("ati")) preferred = Encoder.AMF;
		else if (vendor.contains("intel")) preferred = Encoder.QSV;
		if (preferred != null && available.contains(preferred)) {
			return preferred;
		}
		for (Encoder e : List.of(Encoder.NVENC, Encoder.AMF, Encoder.QSV, Encoder.X264)) {
			if (available.contains(e)) {
				return e;
			}
		}
		return Encoder.X264;
	}

	public String describe() {
		return width + "x" + height + " @ " + fps + " fps - " + encoder.label + " - " + quality.label;
	}
}
