package com.sigmaxox.record.client.plan;

import com.sigmaxox.record.client.config.RecordConfig;
import com.sigmaxox.record.client.config.RecordConfig.Encoder;
import com.sigmaxox.record.client.config.RecordConfig.Quality;
import com.sigmaxox.record.client.hw.HardwareDetect;
import com.sigmaxox.record.client.hw.HardwareDetect.Tier;
import java.util.List;
import java.util.Set;

/** The concrete recording settings that "Auto" resolves to for this machine. */
public record RecordPlan(int width, int height, int fps, Encoder encoder, Quality quality, HardwareDetect.Info hw) {

	public static RecordPlan build(RecordConfig cfg, HardwareDetect.Info hw, Set<Encoder> available, int srcW, int srcH) {
		Encoder enc = pickEncoder(cfg, hw, available);
		boolean hardware = enc != Encoder.X264;
		Tier tier = hw.tier();

		Quality quality = cfg.quality;
		if (quality == Quality.AUTO) {
			quality = tier == Tier.STRONG ? Quality.HIGH : Quality.MEDIUM;
		}

		int fps;
		if (cfg.fps != RecordConfig.Fps.AUTO) {
			fps = cfg.fps.value;
		} else {
			int cap = (tier == Tier.WEAK || (!hardware && tier != Tier.STRONG)) ? 30 : 60;
			fps = Math.min(cap, Math.max(30, hw.refreshHz()));
		}

		int targetH;
		switch (cfg.resolution) {
			case NATIVE -> targetH = srcH;
			case P75 -> targetH = Math.round(srcH * 0.75f);
			case P50 -> targetH = Math.round(srcH * 0.5f);
			case H1080 -> targetH = Math.min(1080, srcH);
			case H720 -> targetH = Math.min(720, srcH);
			case H480 -> targetH = Math.min(480, srcH);
			default -> {
				int cap;
				if (tier == Tier.STRONG) cap = hardware ? 1440 : 1080;
				else if (tier == Tier.MEDIUM) cap = hardware ? 1080 : 720;
				else cap = hardware ? 720 : 480;
				targetH = Math.min(cap, srcH);
			}
		}
		targetH = Math.max(2, targetH);
		int targetW = Math.max(2, Math.round(targetH * (srcW / (float) Math.max(1, srcH))));
		return new RecordPlan(even(targetW), even(targetH), fps, enc, quality, hw);
	}

	private static int even(int v) {
		return Math.max(2, v & ~1);
	}

	private static Encoder pickEncoder(RecordConfig cfg, HardwareDetect.Info hw, Set<Encoder> available) {
		if (cfg.encoder != Encoder.AUTO && available.contains(cfg.encoder)) {
			return cfg.encoder;
		}
		String vendor = (hw.gpuVendor() + " " + hw.gpuName()).toLowerCase();
		Encoder preferred = null;
		if (vendor.contains("nvidia")) preferred = Encoder.NVENC;
		else if (vendor.contains("amd") || vendor.contains("radeon") || vendor.contains("ati")) preferred = Encoder.AMF;
		else if (vendor.contains("intel")) preferred = Encoder.QSV;
		if (preferred != null && available.contains(preferred)) {
			return preferred;
		}
		for (Encoder e : List.of(Encoder.NVENC, Encoder.AMF, Encoder.QSV, Encoder.X264)) {
			if (available.contains(e)) {
				return e;
			}
		}
		return Encoder.X264;
	}

	public String describe() {
		return width + "x" + height + " @ " + fps + " fps - " + encoder.label + " - " + quality.label;
	}
}
