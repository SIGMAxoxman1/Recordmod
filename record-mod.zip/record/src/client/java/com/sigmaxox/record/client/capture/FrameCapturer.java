package com.sigmaxox.record.client.capture;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.ffmpeg.FfmpegEncoder;
import java.nio.ByteBuffer;
import java.util.Optional;
import net.minecraft.client.renderer.RenderPipelines;

/**
 * Reads the finished game frame back from the GPU without stalling it.
 *
 * It uses the same backend-independent mechanism as Minecraft's own screenshots
 * (CommandEncoder.copyTextureToBuffer), so it works on OpenGL and Vulkan.
 * A small ring of buffers is used: a frame is requested now and read a few frames later,
 * when the GPU is done. If every buffer is busy the frame is simply dropped - the render
 * thread never waits.
 *
 * All methods must be called on the render thread.
 */
public final class FrameCapturer {
	private static final int SLOTS = 3;
	private static final int FREE = 0;
	private static final int PENDING = 1;
	private static final int READY = 2;
	// GpuBuffer usage: MAP_READ (1) | COPY_DST (8)
	private static final int BUFFER_USAGE = 9;
	// GpuTexture usage: COPY_SRC (2) | RENDER_ATTACHMENT (8)
	private static final int SCALE_TEXTURE_USAGE = 10;

	private static final class Slot {
		GpuBuffer buffer;
		int state = FREE;
		long tsNs;
		long order;
	}

	private final int outW;
	private final int outH;
	private final long frameBytes;
	private final Slot[] slots = new Slot[SLOTS];
	private GpuTexture scaleTexture;
	private GpuTextureView scaleView;
	private long order;
	private long dropped;
	private long captured;
	private boolean closeRequested;
	private boolean closed;
	private int closeWaitFrames;

	public FrameCapturer(int outW, int outH) {
		this.outW = outW;
		this.outH = outH;
		this.frameBytes = (long) outW * outH * 4L;
		GpuDevice device = RenderSystem.getDevice();
		for (int i = 0; i < SLOTS; i++) {
			Slot s = new Slot();
			s.buffer = device.createBuffer(() -> "Record readback buffer", BUFFER_USAGE, frameBytes);
			slots[i] = s;
		}
	}

	public long dropped() {
		return dropped;
	}

	public long captured() {
		return captured;
	}

	/** Queues a GPU copy of the current frame. Returns false if the frame was dropped. */
	public boolean capture(RenderTarget target, long tsNs) {
		if (closeRequested) {
			return false;
		}
		GpuTexture source = target.getColorTexture();
		GpuTextureView sourceView = target.getColorTextureView();
		if (source == null || sourceView == null) {
			return false;
		}
		Slot slot = freeSlot();
		if (slot == null) {
			dropped++;
			return false;
		}

		GpuDevice device = RenderSystem.getDevice();
		GpuTexture copySource;
		if (target.width == outW && target.height == outH) {
			copySource = source;
		} else {
			ensureScaleTexture(device);
			try (RenderPass pass = device.createCommandEncoder()
				.createRenderPass(() -> "Record scale", scaleView, Optional.empty())) {
				RenderSystem.bindDefaultUniforms(pass);
				pass.setPipeline(RenderPipelines.TRACY_BLIT);
				pass.bindTexture("InSampler", sourceView, RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR));
				pass.draw(3, 1, 0, 0);
			}
			copySource = scaleTexture;
		}

		slot.state = PENDING;
		slot.tsNs = tsNs;
		slot.order = order++;
		CommandEncoder encoder = device.createCommandEncoder();
		encoder.copyTextureToBuffer(copySource, slot.buffer, 0L, () -> slot.state = READY, 0);
		captured++;
		return true;
	}

	/** Moves frames whose GPU copy has finished into the encoder queue. */
	public void poll(FfmpegEncoder encoder) {
		while (true) {
			Slot next = null;
			for (Slot s : slots) {
				if (s.state == READY && (next == null || s.order < next.order)) {
					next = s;
				}
			}
			if (next == null) {
				return;
			}
			byte[] dst = encoder.acquire();
			if (dst == null) {
				dropped++;
				next.state = FREE;
				continue;
			}
			boolean ok = false;
			try (GpuBufferSlice.MappedView view = next.buffer.map(true, false)) {
				ByteBuffer data = view.data().duplicate();
				data.get(dst, 0, (int) Math.min(data.remaining(), frameBytes));
				ok = true;
			} catch (Throwable t) {
				RecordMod.LOGGER.warn("[Record] Could not read back a frame", t);
			}
			next.state = FREE;
			if (!ok || !encoder.offer(new FfmpegEncoder.Frame(dst, next.tsNs))) {
				encoder.release(dst);
				dropped++;
			}
		}
	}

	private Slot freeSlot() {
		for (Slot s : slots) {
			if (s.state == FREE) {
				return s;
			}
		}
		return null;
	}

	private void ensureScaleTexture(GpuDevice device) {
		if (scaleTexture == null) {
			scaleTexture = device.createTexture("Record scale target", SCALE_TEXTURE_USAGE, GpuFormat.RGBA8_UNORM, outW, outH, 1, 1);
			scaleView = device.createTextureView(scaleTexture);
		}
	}

	/** Stop capturing; GPU resources are released once pending copies have finished. */
	public void requestClose() {
		closeRequested = true;
	}

	public boolean isClosed() {
		return closed;
	}

	/** Call once per frame after requestClose(). Returns true when everything is released. */
	public boolean tryFinishClose() {
		if (closed) {
			return true;
		}
		boolean pending = false;
		for (Slot s : slots) {
			if (s.state == PENDING) {
				pending = true;
			}
		}
		// Never wait forever: after ~2 seconds of frames release anyway.
		if (pending && ++closeWaitFrames < 120) {
			return false;
		}
		for (Slot s : slots) {
			s.buffer.close();
		}
		if (scaleView != null) {
			scaleView.close();
		}
		if (scaleTexture != null) {
			scaleTexture.close();
		}
		closed = true;
		return true;
	}
}
