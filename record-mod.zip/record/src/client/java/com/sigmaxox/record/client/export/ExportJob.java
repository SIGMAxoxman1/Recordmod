package com.sigmaxox.record.client.export;

import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.Notify;
import com.sigmaxox.record.client.config.RecordConfig;
import com.sigmaxox.record.client.ffmpeg.FfmpegLocator;
import com.sigmaxox.record.client.replaymod.ReplayModBridge;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;

/**
 * "Export last recording": does by itself what you would do by hand in ReplayMod
 * (Replay Viewer -> open the recording -> Render): opens the newest recording and renders an MP4.
 * Because the recorded camera is applied while it renders, the video shows your real first-person view.
 */
public final class ExportJob {
	private ExportJob() {
	}

	private enum State {
		IDLE, WAIT_FFMPEG, WAIT_LOAD, RENDERING
	}

	private static State state = State.IDLE;
	private static Path replayFile;
	private static String ffmpeg;
	private static long since;
	private static int readyFrames;

	public static boolean busy() {
		return state != State.IDLE;
	}

	public static String label() {
		return busy() ? "Exporting..." : "Export last recording";
	}

	private static Path gameDir() {
		return FabricLoader.getInstance().getGameDir();
	}

	private static Path newestReplay() throws IOException {
		Path dir = gameDir().resolve("replay_recordings");
		if (!Files.isDirectory(dir)) {
			return null;
		}
		try (Stream<Path> files = Files.list(dir)) {
			Optional<Path> newest = files.filter(f -> f.getFileName().toString().endsWith(".mcpr"))
				.max(Comparator.comparingLong(f -> f.toFile().lastModified()));
			return newest.orElse(null);
		}
	}

	/** Button handler (render thread). */
	public static void start(Minecraft mc) {
		if (busy()) {
			return;
		}
		try {
			if (!ReplayModBridge.available()) {
				Notify.problem("ReplayMod is not available: " + ReplayModBridge.problem());
				return;
			}
			if (ReplayModBridge.replayHandler() != null) {
				Notify.problem("A replay is already open. Close it, then press Export.");
				return;
			}
			if (ReplayModBridge.recordingStart() >= 0) {
				Notify.problem("Leave the world first: ReplayMod saves the recording when you leave.");
				return;
			}
			replayFile = newestReplay();
			if (replayFile == null) {
				Notify.problem("No recording found yet (folder: replay_recordings).");
				return;
			}
			ffmpeg = FfmpegLocator.find();
			if (ffmpeg == null) {
				FfmpegLocator.downloadAsync();
				state = State.WAIT_FFMPEG;
				since = System.currentTimeMillis();
				Notify.status("FFmpeg is needed once - downloading it...", false, 5000);
				return;
			}
			openReplay();
		} catch (Throwable t) {
			fail(t);
		}
	}

	private static void openReplay() throws Throwable {
		Notify.status("Opening " + replayFile.getFileName() + " ...", false, 8000);
		ReplayModBridge.startReplay(replayFile.toFile());
		state = State.WAIT_LOAD;
		since = System.currentTimeMillis();
		readyFrames = 0;
	}

	/** Called once per frame (render thread). */
	public static void tick(Minecraft mc) {
		if (state == State.IDLE || state == State.RENDERING) {
			return;
		}
		try {
			if (state == State.WAIT_FFMPEG) {
				switch (FfmpegLocator.state()) {
					case READY -> {
						ffmpeg = FfmpegLocator.find();
						openReplay();
					}
					case FAILED -> {
						Notify.problem(FfmpegLocator.error());
						state = State.IDLE;
					}
					default -> Notify.status("Downloading FFmpeg... " + FfmpegLocator.progress() + "%", false, 3000);
				}
				return;
			}
			// WAIT_LOAD: the replay opens like in the Replay Viewer; wait until its world is up and calm.
			Object handler = ReplayModBridge.replayHandler();
			long waited = System.currentTimeMillis() - since;
			if (handler != null && mc.level != null && mc.player != null && ReplayModBridge.cameraEntity(handler) != null) {
				readyFrames++;
			} else {
				readyFrames = 0;
			}
			if (readyFrames >= 45 && waited >= 2500) {
				state = State.RENDERING;
				Object h = handler;
				mc.execute(() -> render(mc, h));
			} else if (waited > 180_000) {
				Notify.problem("The recording did not open. If a window asked about mods, click Load and press Export again.");
				state = State.IDLE;
			}
		} catch (Throwable t) {
			fail(t);
		}
	}

	private static void render(Minecraft mc, Object handler) {
		try {
			RecordConfig cfg = RecordConfig.get();
			int duration = ReplayModBridge.replayDuration(handler);
			Object timeline = ReplayModBridge.newPlainTimeline(duration);

			Path outDir = gameDir().resolve("exports");
			Files.createDirectories(outDir);
			String base = replayFile.getFileName().toString().replaceAll("\\.mcpr$", "");
			Path out = outDir.resolve(base + ".mp4");
			for (int i = 1; Files.exists(out); i++) {
				out = outDir.resolve(base + "_" + i + ".mp4");
			}
			Object settings = ReplayModBridge.newRenderSettings(cfg.exportWidth, cfg.exportHeight, cfg.exportFps,
				cfg.exportBitrateMbit << 20, out.toFile(), "ffmpeg".equals(ffmpeg) ? "" : ffmpeg);
			RecordMod.LOGGER.info("[Record] Exporting {} ({} s) to {}", replayFile.getFileName(), duration / 1000, out);
			boolean ok = ReplayModBridge.renderVideo(settings, handler, timeline);
			if (ok && Files.isRegularFile(out)) {
				Notify.chat("Exported: exports/" + out.getFileName() + String.format(" (%.0f MB)", Files.size(out) / 1e6));
			} else {
				Notify.problem("The export did not finish (cancelled or failed). See the log for details.");
			}
		} catch (Throwable t) {
			fail(t);
		} finally {
			ReplayModBridge.endReplay(handler);
			state = State.IDLE;
		}
	}

	private static void fail(Throwable t) {
		RecordMod.LOGGER.warn("[Record] Export failed", t);
		String why = String.valueOf(t.getMessage());
		if (t.getClass().getSimpleName().contains("FFmpeg")) {
			why = "FFmpeg could not be started";
		}
		Notify.problem("Export failed: " + why);
		state = State.IDLE;
	}
}
