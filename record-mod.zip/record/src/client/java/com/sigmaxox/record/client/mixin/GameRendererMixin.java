package com.sigmaxox.record.client.mixin;

import com.sigmaxox.record.client.replaymod.CameraCompanion;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
	/** End of the frame: the main camera now holds the pose this frame was drawn with. */
	@Inject(method = "render(Lnet/minecraft/client/DeltaTracker;Z)V", at = @At("TAIL"))
	private void record$frameEnd(CallbackInfo ci) {
		CameraCompanion.onFrameEnd(Minecraft.getInstance());
	}

	/** The game updates its camera here, before it draws the frame: a second chance to show a replay's recorded camera. */
	@Inject(method = "update(Lnet/minecraft/client/DeltaTracker;)V", at = @At("HEAD"))
	private void record$beforeCameraUpdate(CallbackInfo ci) {
		CameraCompanion.applyReplayCamera(Minecraft.getInstance());
	}
}
