package com.sigmaxox.record.client.mixin;

import com.sigmaxox.record.client.Recorder;
import com.sigmaxox.record.client.replaymod.CameraCompanion;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * End of GameRenderer.render(): the main render target now holds the finished picture
 * (world + HUD + every menu), which is exactly what the player sees.
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
	@Inject(method = "render(Lnet/minecraft/client/DeltaTracker;Z)V", at = @At("TAIL"))
	private void record$frameEnd(CallbackInfo ci) {
		Recorder.INSTANCE.onFrameEnd(((GameRenderer) (Object) this).mainRenderTarget());
		CameraCompanion.onFrameEnd(Minecraft.getInstance());
	}

	/** The game updates its camera here, before it draws the frame: the place to show a replay's recorded camera. */
	@Inject(method = "update(Lnet/minecraft/client/DeltaTracker;)V", at = @At("HEAD"))
	private void record$beforeCameraUpdate(CallbackInfo ci) {
		CameraCompanion.beforeCameraUpdate(Minecraft.getInstance());
	}
}
