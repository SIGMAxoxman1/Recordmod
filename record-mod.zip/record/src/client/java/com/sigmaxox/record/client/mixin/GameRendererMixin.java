package com.sigmaxox.record.client.mixin;

import com.sigmaxox.record.client.Recorder;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * End of GameRenderer.render(): the main render target now holds the finished picture
 * (world + HUD + every menu), which is exactly what the player sees.
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
	@Inject(method = "render(Lnet/minecraft/client/DeltaTracker;Z)V", at = @At("TAIL"))
	private void record$frameEnd(CallbackInfo ci) {
		Recorder.INSTANCE.onFrameEnd(((GameRenderer) (Object) this).mainRenderTarget());
	}
}
