package com.sigmaxox.record.client.raw;

/** RGBA (GPU order, bottom row first) -> I420 (top row first, BT.709 limited range). Pure integer math. */
public final class Yuv {
	private Yuv() {
	}

	public static int i420Size(int w, int h) {
		return w * h + 2 * (w / 2) * (h / 2);
	}

	/** w and h must be even. rgba.length >= w*h*4, out.length >= i420Size(w, h). */
	public static void rgbaBottomUpToI420(byte[] rgba, int w, int h, byte[] out) {
		int ySize = w * h;
		int cw = w / 2;
		int uOff = ySize;
		int vOff = ySize + cw * (h / 2);
		int rowBytes = w * 4;
		for (int y = 0; y < h; y += 2) {
			int s0 = (h - 1 - y) * rowBytes;      // source row of output row y
			int s1 = (h - 2 - y) * rowBytes;      // source row of output row y + 1
			int d0 = y * w;
			int d1 = d0 + w;
			int c = (y >> 1) * cw;
			for (int x = 0; x < w; x += 2) {
				int i0 = s0 + (x << 2);
				int i1 = s1 + (x << 2);
				int r00 = rgba[i0] & 0xFF, g00 = rgba[i0 + 1] & 0xFF, b00 = rgba[i0 + 2] & 0xFF;
				int r01 = rgba[i0 + 4] & 0xFF, g01 = rgba[i0 + 5] & 0xFF, b01 = rgba[i0 + 6] & 0xFF;
				int r10 = rgba[i1] & 0xFF, g10 = rgba[i1 + 1] & 0xFF, b10 = rgba[i1 + 2] & 0xFF;
				int r11 = rgba[i1 + 4] & 0xFF, g11 = rgba[i1 + 5] & 0xFF, b11 = rgba[i1 + 6] & 0xFF;

				out[d0 + x] = (byte) (((47 * r00 + 157 * g00 + 16 * b00 + 128) >> 8) + 16);
				out[d0 + x + 1] = (byte) (((47 * r01 + 157 * g01 + 16 * b01 + 128) >> 8) + 16);
				out[d1 + x] = (byte) (((47 * r10 + 157 * g10 + 16 * b10 + 128) >> 8) + 16);
				out[d1 + x + 1] = (byte) (((47 * r11 + 157 * g11 + 16 * b11 + 128) >> 8) + 16);

				int r = (r00 + r01 + r10 + r11 + 2) >> 2;
				int g = (g00 + g01 + g10 + g11 + 2) >> 2;
				int b = (b00 + b01 + b10 + b11 + 2) >> 2;
				int ci = c + (x >> 1);
				out[uOff + ci] = (byte) (((-26 * r - 87 * g + 112 * b + 128) >> 8) + 128);
				out[vOff + ci] = (byte) (((112 * r - 102 * g - 10 * b + 128) >> 8) + 128);
			}
		}
	}
}
