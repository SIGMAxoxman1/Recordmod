package com.sigmaxox.record.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sigmaxox.record.RecordMod;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

/** User settings, stored in config/record.json. Every option defaults to AUTO. */
public final class RecordConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static RecordConfig instance;

	/** LIGHT: store raw frames, convert to MP4 afterwards. REPLAY: keep only the last few minutes, save clips on demand. LIVE: encode MP4 while playing. */
	public enum Mode {
		LIGHT("Light"), REPLAY("Replay"), LIVE("Live MP4");

		public final String label;

		Mode(String label) {
			this.label = label;
		}
	}

	public enum Resolution {
		AUTO("Auto"), NATIVE("Native"), P75("75%"), P50("50%"), H1080("1080p"), H720("720p"), H480("480p");

		public final String label;

		Resolution(String label) {
			this.label = label;
		}
	}

	public enum Fps {
		AUTO("Auto", 0), F24("24", 24), F30("30", 30), F60("60", 60), F120("120", 120);

		public final String label;
		public final int value;

		Fps(String label, int value) {
			this.label = label;
			this.value = value;
		}
	}

	public enum Encoder {
		AUTO("Auto"), NVENC("NVENC (NVIDIA)"), AMF("AMF (AMD)"), QSV("QuickSync (Intel)"), X264("x264 (CPU)");

		public final String label;

		Encoder(String label) {
			this.label = label;
		}
	}

	public enum Quality {
		AUTO("Auto"), LOW("Low"), MEDIUM("Medium"), HIGH("High");

		public final String label;

		Quality(String label) {
			this.label = label;
		}
	}

	public Mode mode = Mode.LIVE;
	/**
	 * Target size of the finished MP4 in GB per 10 minutes (Live mode and conversion).
	 * The encoder is given the matching bitrate: 1.0 GB / 10 min = about 13 Mbit/s. 0 = choose by quality instead.
	 */
	public double targetGbPer10Min = 1.0;
	/** Light mode: convert to MP4 automatically right after stopping (off = convert later from the settings). */
	public boolean autoConvert = false;
	public boolean deleteRawAfterConvert = true;
	/** Light mode "Auto" picks the biggest resolution whose raw size per 10 minutes stays under this (GB). */
	public double budgetGbPer10Min = 25.0;
	/** Light mode: a recording stops by itself when its file reaches this size (GB)... */
	public double maxSizeGb = 40.0;
	/** ...or when the free disk space drops below this (GB). */
	public double minFreeGb = 3.0;
	/** Replay mode: how many minutes of play are kept (the disk use stays constant). */
	public double bufferMinutes = 5.0;
	/** Replay mode: length of a saved clip. */
	public double clipSeconds = 120.0;
	/** GLFW key code for "save clip" in Replay mode. 299 = F10. */
	public int clipHotkey = 299;
	public Resolution resolution = Resolution.AUTO;
	public Fps fps = Fps.AUTO;
	public Encoder encoder = Encoder.AUTO;
	public Quality quality = Quality.AUTO;
	/** The REC indicator is drawn on the game screen, so it is also visible in the video. */
	public boolean showIndicator = true;
	/** GLFW key code. 298 = F9. */
	public int hotkey = 298;
	/** Empty = auto-detect (own download folder, then PATH). */
	public String ffmpegPath = "";
	/** Empty = <game folder>/recordings */
	public String outputDir = "";

	public static synchronized RecordConfig get() {
		if (instance == null) {
			instance = load();
		}
		return instance;
	}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("record.json");
	}

	private static RecordConfig load() {
		RecordConfig cfg = null;
		try {
			Path f = file();
			if (Files.isRegularFile(f)) {
				cfg = GSON.fromJson(Files.readString(f), RecordConfig.class);
			}
		} catch (Exception e) {
			RecordMod.LOGGER.warn("[Record] Could not read config, using defaults", e);
		}
		if (cfg == null) {
			cfg = new RecordConfig();
		}
		cfg.sanitize();
		return cfg;
	}

	private void sanitize() {
		if (mode == null) mode = Mode.LIVE;
		if (targetGbPer10Min < 0) targetGbPer10Min = 1.0;
		if (bufferMinutes <= 0) bufferMinutes = 5.0;
		if (clipSeconds <= 0) clipSeconds = 120.0;
		if (clipHotkey <= 0) clipHotkey = 299;
		if (budgetGbPer10Min <= 0) budgetGbPer10Min = 25.0;
		if (maxSizeGb <= 0) maxSizeGb = 40.0;
		if (minFreeGb < 0) minFreeGb = 3.0;
		if (resolution == null) resolution = Resolution.AUTO;
		if (fps == null) fps = Fps.AUTO;
		if (encoder == null) encoder = Encoder.AUTO;
		if (quality == null) quality = Quality.AUTO;
		if (ffmpegPath == null) ffmpegPath = "";
		if (outputDir == null) outputDir = "";
		if (hotkey <= 0) hotkey = 298;
	}

	public synchronized void save() {
		try {
			Files.createDirectories(file().getParent());
			Files.writeString(file(), GSON.toJson(this));
		} catch (IOException e) {
			RecordMod.LOGGER.warn("[Record] Could not save config", e);
		}
	}

	public static Path recordingsDir() {
		RecordConfig cfg = get();
		return cfg.outputDir.isBlank()
			? FabricLoader.getInstance().getGameDir().resolve("recordings")
			: Path.of(cfg.outputDir);
	}

	public static <E extends Enum<E>> E next(E value) {
		E[] all = value.getDeclaringClass().getEnumConstants();
		return all[(value.ordinal() + 1) % all.length];
	}
}
