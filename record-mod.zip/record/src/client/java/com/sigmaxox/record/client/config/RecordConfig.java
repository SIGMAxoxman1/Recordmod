package com.sigmaxox.record.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sigmaxox.record.RecordMod;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

/** Settings, stored in config/record.json. */
public final class RecordConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static RecordConfig instance;

	/** Record the real camera of every frame while ReplayMod records, and show it in replays and exports. */
	public boolean replayCamera = true;

	public static synchronized RecordConfig get() {
		if (instance == null) {
			instance = load();
		}
		return instance;
	}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("record.json");
	}

	private static RecordConfig load() {
		RecordConfig cfg = null;
		try {
			Path f = file();
			if (Files.isRegularFile(f)) {
				cfg = GSON.fromJson(Files.readString(f), RecordConfig.class);
			}
		} catch (Exception e) {
			RecordMod.LOGGER.warn("[Record] Could not read config, using defaults", e);
		}
		return cfg == null ? new RecordConfig() : cfg;
	}

	public synchronized void save() {
		try {
			Files.createDirectories(file().getParent());
			Files.writeString(file(), GSON.toJson(this));
		} catch (IOException e) {
			RecordMod.LOGGER.warn("[Record] Could not save config", e);
		}
	}
}
