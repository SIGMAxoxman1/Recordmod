package com.sigmaxox.record.client.replaymod;

import com.sigmaxox.record.RecordMod;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Talks to ReplayMod through reflection only, so this mod does not need ReplayMod to compile or to start.
 * Every name used here was read from ReplayMod's source (stable branch, 2.6.x). If ReplayMod changes and a
 * name no longer exists, the bridge turns itself off, logs once, and nothing else is affected.
 */
public final class ReplayModBridge {
	private ReplayModBridge() {
	}

	private static boolean initialised;
	private static boolean usable;
	private static String problem = "";

	private static Field recInstance;          // ReplayModRecording.instance
	private static Method recGetHandler;       // .getConnectionEventHandler()
	private static Method handlerGetListener;  // ConnectionEventHandler.getPacketListener()
	private static Field listenerStart;        // PacketListener.startTime
	private static Field listenerPaused;       // PacketListener.timePassedWhilePaused

	private static Field repInstance;          // ReplayModReplay.instance
	private static Method repGetHandler;       // .getReplayHandler()

	public static String problem() {
		return problem;
	}

	/** True if ReplayMod is installed and its API matched. */
	public static synchronized boolean available() {
		if (!initialised) {
			initialised = true;
			try {
				Class<?> rec = Class.forName("com.replaymod.recording.ReplayModRecording");
				recInstance = rec.getField("instance");
				recGetHandler = rec.getMethod("getConnectionEventHandler");
				Class<?> ceh = Class.forName("com.replaymod.recording.handler.ConnectionEventHandler");
				handlerGetListener = ceh.getMethod("getPacketListener");
				Class<?> pl = Class.forName("com.replaymod.recording.packet.PacketListener");
				listenerStart = pl.getDeclaredField("startTime");
				listenerStart.setAccessible(true);
				listenerPaused = pl.getDeclaredField("timePassedWhilePaused");
				listenerPaused.setAccessible(true);

				Class<?> rep = Class.forName("com.replaymod.replay.ReplayModReplay");
				repInstance = rep.getField("instance");
				repGetHandler = rep.getMethod("getReplayHandler");
				usable = true;
			} catch (ClassNotFoundException e) {
				problem = "ReplayMod is not installed";
			} catch (Throwable t) {
				problem = "ReplayMod's API is different from the one this mod knows: " + t;
				RecordMod.LOGGER.warn("[Record] ReplayMod companion disabled: {}", problem);
			}
		}
		return usable;
	}

	private static void disable(Throwable t) {
		if (usable) {
			usable = false;
			problem = String.valueOf(t);
			RecordMod.LOGGER.warn("[Record] ReplayMod companion turned off after an error", t);
		}
	}

	// ---------------- recording side ----------------

	private static Object packetListener() throws ReflectiveOperationException {
		Object mod = recInstance.get(null);
		if (mod == null) {
			return null;
		}
		Object handler = recGetHandler.invoke(mod);
		return handler == null ? null : handlerGetListener.invoke(handler);
	}

	/** Epoch milliseconds at which the current ReplayMod recording started, or -1 if it is not recording. */
	public static long recordingStart() {
		if (!available()) {
			return -1;
		}
		try {
			Object listener = packetListener();
			return listener == null ? -1 : listenerStart.getLong(listener);
		} catch (Throwable t) {
			disable(t);
			return -1;
		}
	}

	/** Milliseconds ReplayMod has removed from its timeline because the game was paused. */
	public static long recordingPausedMs() {
		try {
			Object listener = packetListener();
			return listener == null ? 0 : listenerPaused.getLong(listener);
		} catch (Throwable t) {
			disable(t);
			return 0;
		}
	}

	// ---------------- replay side ----------------

	/** The ReplayHandler of the replay that is open right now, or null. */
	public static Object replayHandler() {
		if (!available()) {
			return null;
		}
		try {
			Object mod = repInstance.get(null);
			return mod == null ? null : repGetHandler.invoke(mod);
		} catch (Throwable t) {
			disable(t);
			return null;
		}
	}


	private static final Map<String, Method> BY_NAME = new HashMap<>();

	private static Object call(Object target, String name, Object... args) throws ReflectiveOperationException {
		String key = target.getClass().getName() + "#" + name + "/" + args.length;
		Method m = BY_NAME.get(key);
		if (m == null) {
			for (Method candidate : target.getClass().getMethods()) {
				if (candidate.getName().equals(name) && candidate.getParameterCount() == args.length) {
					m = candidate;
					break;
				}
			}
			if (m == null) {
				throw new NoSuchMethodException(target.getClass().getName() + "." + name);
			}
			m.setAccessible(true);
			BY_NAME.put(key, m);
		}
		return m.invoke(target, args);
	}

	/** Start time (epoch ms) stored in the open replay's metadata. Timestamps of the replay count from here. */
	public static long replayStart(Object handler) {
		try {
			Object file = call(handler, "getReplayFile");
			Object meta = call(file, "getMetaData");
			return ((Number) call(meta, "getDate")).longValue();
		} catch (Throwable t) {
			disable(t);
			return -1;
		}
	}

	/** Current position of the replay in milliseconds. */
	public static int replayTime(Object handler) {
		try {
			Object sender = call(handler, "getReplaySender");
			return ((Number) call(sender, "currentTimeStamp")).intValue();
		} catch (Throwable t) {
			disable(t);
			return -1;
		}
	}

	/** ReplayMod's free camera entity (an Entity), or null. */
	public static Object cameraEntity(Object handler) {
		try {
			return call(handler, "getCameraEntity");
		} catch (Throwable t) {
			disable(t);
			return null;
		}
	}

	/** Makes the free camera the view (instead of spectating a player). */
	public static void useFreeCamera(Object handler) {
		try {
			call(handler, "spectateCamera");
		} catch (Throwable t) {
			disable(t);
		}
	}

	/** Puts ReplayMod's camera exactly at this pose (no interpolation between frames). */
	public static boolean setCamera(Object camera, double x, double y, double z, float yaw, float pitch) {
		try {
			call(camera, "setCameraRotation", yaw, pitch, 0.0F);
			call(camera, "setCameraPosition", x, y, z);
			return true;
		} catch (Throwable t) {
			disable(t);
			return false;
		}
	}
}
