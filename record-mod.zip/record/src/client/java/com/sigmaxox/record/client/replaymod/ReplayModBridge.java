package com.sigmaxox.record.client.replaymod;

import com.sigmaxox.record.RecordMod;
import java.lang.reflect.Field;
import java.lang.reflect.Proxy;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Talks to ReplayMod through reflection only, so this mod does not need ReplayMod to compile or to start.
 * Every name used here was read from ReplayMod's source (stable branch, 2.6.x). If ReplayMod changes and a
 * name no longer exists, the bridge turns itself off, logs once, and nothing else is affected.
 */
public final class ReplayModBridge {
	private ReplayModBridge() {
	}

	private static boolean initialised;
	private static boolean usable;
	private static String problem = "";

	private static Field recInstance;          // ReplayModRecording.instance
	private static Method recGetHandler;       // .getConnectionEventHandler()
	private static Method handlerGetListener;  // ConnectionEventHandler.getPacketListener()
	private static Field listenerStart;        // PacketListener.startTime
	private static Field listenerPaused;       // PacketListener.timePassedWhilePaused

	private static Field repInstance;          // ReplayModReplay.instance
	private static Method repGetHandler;       // .getReplayHandler()

	public static String problem() {
		return problem;
	}

	/** True if ReplayMod is installed and its API matched. */
	public static synchronized boolean available() {
		if (!initialised) {
			initialised = true;
			try {
				Class<?> rec = Class.forName("com.replaymod.recording.ReplayModRecording");
				recInstance = rec.getField("instance");
				recGetHandler = rec.getMethod("getConnectionEventHandler");
				Class<?> ceh = Class.forName("com.replaymod.recording.handler.ConnectionEventHandler");
				handlerGetListener = ceh.getMethod("getPacketListener");
				Class<?> pl = Class.forName("com.replaymod.recording.packet.PacketListener");
				listenerStart = pl.getDeclaredField("startTime");
				listenerStart.setAccessible(true);
				listenerPaused = pl.getDeclaredField("timePassedWhilePaused");
				listenerPaused.setAccessible(true);

				Class<?> rep = Class.forName("com.replaymod.replay.ReplayModReplay");
				repInstance = rep.getField("instance");
				repGetHandler = rep.getMethod("getReplayHandler");
				usable = true;
			} catch (ClassNotFoundException e) {
				problem = "ReplayMod is not installed";
			} catch (Throwable t) {
				problem = "ReplayMod's API is different from the one this mod knows: " + t;
				RecordMod.LOGGER.warn("[Record] ReplayMod companion disabled: {}", problem);
			}
		}
		return usable;
	}

	private static void disable(Throwable t) {
		if (usable) {
			usable = false;
			problem = String.valueOf(t);
			RecordMod.LOGGER.warn("[Record] ReplayMod companion turned off after an error", t);
		}
	}

	// ---------------- recording side ----------------

	private static Object packetListener() throws ReflectiveOperationException {
		Object mod = recInstance.get(null);
		if (mod == null) {
			return null;
		}
		Object handler = recGetHandler.invoke(mod);
		return handler == null ? null : handlerGetListener.invoke(handler);
	}

	/** Epoch milliseconds at which the current ReplayMod recording started, or -1 if it is not recording. */
	public static long recordingStart() {
		if (!available()) {
			return -1;
		}
		try {
			Object listener = packetListener();
			return listener == null ? -1 : listenerStart.getLong(listener);
		} catch (Throwable t) {
			disable(t);
			return -1;
		}
	}

	/** Milliseconds ReplayMod has removed from its timeline because the game was paused. */
	public static long recordingPausedMs() {
		try {
			Object listener = packetListener();
			return listener == null ? 0 : listenerPaused.getLong(listener);
		} catch (Throwable t) {
			disable(t);
			return 0;
		}
	}

	// ---------------- replay side ----------------

	/** The ReplayHandler of the replay that is open right now, or null. */
	public static Object replayHandler() {
		if (!available()) {
			return null;
		}
		try {
			Object mod = repInstance.get(null);
			return mod == null ? null : repGetHandler.invoke(mod);
		} catch (Throwable t) {
			disable(t);
			return null;
		}
	}


	private static final Map<String, Method> BY_NAME = new HashMap<>();

	private static boolean accepts(Class<?> param, Object arg) {
		if (arg == null) {
			return !param.isPrimitive();
		}
		if (param.isPrimitive()) {
			Class<?> w = java.lang.reflect.Array.get(java.lang.reflect.Array.newInstance(param, 1), 0).getClass();
			return w.isInstance(arg);
		}
		return param.isInstance(arg);
	}

	/** Calls a public method by name; picks the overload whose parameter types fit the arguments. */
	private static Object call(Object target, String name, Object... args) throws ReflectiveOperationException {
		StringBuilder key = new StringBuilder(target.getClass().getName()).append('#').append(name);
		for (Object a : args) {
			key.append('/').append(a == null ? "null" : a.getClass().getName());
		}
		Method m = BY_NAME.get(key.toString());
		if (m == null) {
			for (Method candidate : target.getClass().getMethods()) {
				if (!candidate.getName().equals(name) || candidate.getParameterCount() != args.length) {
					continue;
				}
				boolean fits = true;
				Class<?>[] types = candidate.getParameterTypes();
				for (int i = 0; i < types.length && fits; i++) {
					fits = accepts(types[i], args[i]);
				}
				if (fits) {
					m = candidate;
					break;
				}
			}
			if (m == null) {
				throw new NoSuchMethodException(target.getClass().getName() + "." + name);
			}
			m.setAccessible(true);
			BY_NAME.put(key.toString(), m);
		}
		return m.invoke(target, args);
	}

	/** Start time (epoch ms) stored in the open replay's metadata. Timestamps of the replay count from here. */
	public static long replayStart(Object handler) {
		try {
			Object file = call(handler, "getReplayFile");
			Object meta = call(file, "getMetaData");
			return ((Number) call(meta, "getDate")).longValue();
		} catch (Throwable t) {
			disable(t);
			return -1;
		}
	}

	/** Current position of the replay in milliseconds. */
	public static int replayTime(Object handler) {
		try {
			Object sender = call(handler, "getReplaySender");
			return ((Number) call(sender, "currentTimeStamp")).intValue();
		} catch (Throwable t) {
			disable(t);
			return -1;
		}
	}

	/** ReplayMod's free camera entity (an Entity), or null. */
	public static Object cameraEntity(Object handler) {
		try {
			return call(handler, "getCameraEntity");
		} catch (Throwable t) {
			disable(t);
			return null;
		}
	}

	/**
	 * Runs {@code action} at the start of every frame, both while a replay plays and while it is exported,
	 * using ReplayMod's own PreRenderCallback event. Listeners run in the order they were registered, so
	 * register after ReplayMod's camera has been created to run after ReplayMod's own camera update.
	 *
	 * @return a token for {@link #unregisterPreRender}, or null if it could not be registered
	 */
	public static Object registerPreRender(Runnable action) {
		try {
			Class<?> callback = Class.forName("com.replaymod.core.events.PreRenderCallback");
			Object event = callback.getField("EVENT").get(null);
			Object listener = Proxy.newProxyInstance(callback.getClassLoader(), new Class<?>[] {callback}, (proxy, method, args) -> {
				switch (method.getName()) {
					case "preRender" -> action.run();
					case "hashCode" -> {
						return System.identityHashCode(proxy);
					}
					case "equals" -> {
						return proxy == args[0];
					}
					case "toString" -> {
						return "Record camera listener";
					}
					default -> {
					}
				}
				return null;
			});
			call(event, "register", listener);
			return new Object[] {event, listener};
		} catch (Throwable t) {
			RecordMod.LOGGER.warn("[Record] Could not attach to ReplayMod's per-frame event (the camera still works in the live preview)", t);
			return null;
		}
	}

	public static void unregisterPreRender(Object token) {
		if (token instanceof Object[] pair && pair.length == 2) {
			try {
				call(pair[0], "unregister", pair[1]);
			} catch (Throwable ignored) {
			}
		}
	}

	/** Makes the free camera the view (instead of spectating a player). */
	public static void useFreeCamera(Object handler) {
		try {
			call(handler, "spectateCamera");
		} catch (Throwable t) {
			disable(t);
		}
	}

	/** Puts ReplayMod's camera exactly at this pose (no interpolation between frames). */
	public static boolean setCamera(Object camera, double x, double y, double z, float yaw, float pitch) {
		try {
			call(camera, "setCameraRotation", yaw, pitch, 0.0F);
			call(camera, "setCameraPosition", x, y, z);
			return true;
		} catch (Throwable t) {
			disable(t);
			return false;
		}
	}

	// ---------------- export (what ReplayMod's own "Render" button does) ----------------

	private static Object enumConstant(Class<?> type, String name) {
		for (Object c : type.getEnumConstants()) {
			if (((Enum<?>) c).name().equals(name)) {
				return c;
			}
		}
		throw new IllegalArgumentException(type.getName() + " has no " + name);
	}

	/** Opens a replay file like the Replay Viewer does. The replay loads over the next moments. */
	public static void startReplay(java.io.File file) throws Throwable {
		if (!available()) {
			throw new IllegalStateException(problem);
		}
		try {
			call(repInstance.get(null), "startReplay", file);
		} catch (java.lang.reflect.InvocationTargetException e) {
			throw e.getCause();
		}
	}

	/** Length of the open replay in milliseconds. */
	public static int replayDuration(Object handler) throws ReflectiveOperationException {
		Object meta = call(call(handler, "getReplayFile"), "getMetaData");
		return ((Number) call(meta, "getDuration")).intValue();
	}

	/** A camera path with only "time" keyframes (start -> end at normal speed): the view stays with the camera entity. */
	public static Object newPlainTimeline(int durationMs) throws ReflectiveOperationException {
		Object sp = Class.forName("com.replaymod.simplepathing.SPTimeline").getConstructor().newInstance();
		call(sp, "addTimeKeyframe", Long.valueOf(0L), Integer.valueOf(0));
		call(sp, "addTimeKeyframe", Long.valueOf(durationMs), Integer.valueOf(durationMs));
		return call(sp, "getTimeline");
	}

	/** ReplayMod's render settings: MP4, with the given size, frame rate and bitrate. */
	public static Object newRenderSettings(int width, int height, int fps, int bitrateBitsPerSecond,
										   java.io.File output, String ffmpegCommand) throws ReflectiveOperationException {
		Class<?> rs = Class.forName("com.replaymod.render.RenderSettings");
		Class<?> methodType = Class.forName("com.replaymod.render.RenderSettings$RenderMethod");
		Class<?> presetType = Class.forName("com.replaymod.render.RenderSettings$EncodingPreset");
		Class<?> aaType = Class.forName("com.replaymod.render.RenderSettings$AntiAliasing");
		Object preset = enumConstant(presetType, "MP4_CUSTOM");
		Object presetArguments = call(preset, "getValue");
		java.lang.reflect.Constructor<?> ctor = null;
		for (java.lang.reflect.Constructor<?> c : rs.getConstructors()) {
			if (c.getParameterCount() == 22) {
				ctor = c;
			}
		}
		if (ctor == null) {
			throw new NoSuchMethodException("RenderSettings has no 22-argument constructor");
		}
		Object[] args = {
			enumConstant(methodType, "DEFAULT"), preset, width, height, fps, bitrateBitsPerSecond, output,
			true,                       // render name tags
			false, false, false, false, // alpha channel, stabilise yaw / pitch / roll
			null,                       // chroma key colour
			360, 180, false,            // spherical settings
			false, false,               // depth map, camera path export
			enumConstant(aaType, "NONE"),
			ffmpegCommand == null ? "" : ffmpegCommand, presetArguments,
			false                       // high performance
		};
		return ctor.newInstance(args);
	}

	/** Renders the video (blocks until it is finished or fails). Same call as ReplayMod's Render button. */
	public static boolean renderVideo(Object settings, Object handler, Object timeline) throws Throwable {
		Class<?> vr = Class.forName("com.replaymod.render.rendering.VideoRenderer");
		java.lang.reflect.Constructor<?> ctor = null;
		for (java.lang.reflect.Constructor<?> c : vr.getConstructors()) {
			if (c.getParameterCount() == 3) {
				ctor = c;
			}
		}
		if (ctor == null) {
			throw new NoSuchMethodException("VideoRenderer has no 3-argument constructor");
		}
		try {
			Object renderer = ctor.newInstance(settings, handler, timeline);
			return Boolean.TRUE.equals(call(renderer, "renderVideo"));
		} catch (java.lang.reflect.InvocationTargetException e) {
			throw e.getCause();
		}
	}

	public static void endReplay(Object handler) {
		try {
			call(handler, "endReplay");
		} catch (Throwable ignored) {
		}
	}

	/** Value of one of ReplayMod's recording settings (for example "AUTO_START_RECORDING"), or null if unknown. */
	public static Boolean recordingSetting(String fieldName) {
		try {
			Object mod = Class.forName("com.replaymod.core.ReplayMod").getField("instance").get(null);
			Object registry = call(mod, "getSettingsRegistry");
			Object key = Class.forName("com.replaymod.recording.Setting").getField(fieldName).get(null);
			return (Boolean) call(registry, "get", key);
		} catch (Throwable t) {
			return null;
		}
	}
}
