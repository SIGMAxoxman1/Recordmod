package com.sigmaxox.record.client.raw;

import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.Recorder;
import com.sigmaxox.record.client.config.RecordConfig;
import com.sigmaxox.record.client.ffmpeg.FfmpegEncoder;
import com.sigmaxox.record.client.ffmpeg.FfmpegManager;
import com.sigmaxox.record.client.ffmpeg.FrameSink;
import com.sigmaxox.record.client.hw.HardwareDetect;
import com.sigmaxox.record.client.plan.RecordPlan;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Deque;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.client.Minecraft;

/**
 * Turns Light-mode recordings (.rawv files) and Replay-buffer clips (clip_* folders) into MP4
 * with FFmpeg. Meant to run after you finish playing.
 */
public final class RawConverter {
	private RawConverter() {
	}

	private static final Deque<Path> QUEUE = new ArrayDeque<>();
	private static volatile boolean running;
	private static volatile String currentName = "";
	private static volatile int progress;
	private static HardwareDetect.Info hw;

	public static boolean isRunning() {
		return running;
	}

	public static String currentName() {
		return currentName;
	}

	public static int progress() {
		return progress;
	}

	/** Raw recordings and clip folders that have no MP4 yet. */
	public static List<Path> pending() {
		Path dir = RecordConfig.recordingsDir();
		List<Path> result = new ArrayList<>();
		if (!Files.isDirectory(dir)) {
			return result;
		}
		try (Stream<Path> files = Files.list(dir)) {
			files.filter(f -> {
				String n = f.getFileName().toString();
				if (Files.isDirectory(f)) {
					return n.startsWith("clip_") && !segments(f).isEmpty();
				}
				return n.endsWith(".rawv");
			}).sorted().forEach(result::add);
		} catch (IOException ignored) {
		}
		return result;
	}

	private static List<Path> segments(Path job) {
		if (!Files.isDirectory(job)) {
			return List.of(job);
		}
		try (Stream<Path> files = Files.list(job)) {
			return files.filter(f -> f.getFileName().toString().endsWith(".rawv")).sorted().toList();
		} catch (IOException e) {
			return List.of();
		}
	}

	/** Render thread. Starts converting every pending recording (downloads FFmpeg first if needed). */
	public static synchronized void convertPending(Minecraft mc) {
		List<Path> files = pending();
		synchronized (QUEUE) {
			files.removeIf(QUEUE::contains);
		}
		if (files.isEmpty() && !running) {
			Recorder.INSTANCE.setStatus("Nothing to convert.", false, 4000);
			return;
		}
		switch (FfmpegManager.state()) {
			case READY -> {
			}
			case DOWNLOADING, SEARCHING, PROBING, UNKNOWN -> {
				Recorder.INSTANCE.setStatus("Preparing FFmpeg, please wait a moment and try again...", false, 6000);
				return;
			}
			default -> {
				FfmpegManager.downloadAsync();
				Recorder.INSTANCE.setStatus(FfmpegManager.state() == FfmpegManager.State.FAILED
					? FfmpegManager.error()
					: "FFmpeg is missing - downloading it now. Press Convert again when it finishes.",
					FfmpegManager.state() == FfmpegManager.State.FAILED, 9000);
				return;
			}
		}
		hw = HardwareDetect.detect(mc);
		synchronized (QUEUE) {
			QUEUE.addAll(files);
		}
		if (!running) {
			running = true;
			Thread t = new Thread(RawConverter::work, "Record-Converter");
			t.setDaemon(true);
			t.start();
		}
		Recorder.INSTANCE.setStatus("Converting " + files.size() + " recording(s) to MP4...", false, 5000);
	}

	private static void work() {
		try {
			while (true) {
				Path job;
				synchronized (QUEUE) {
					job = QUEUE.poll();
				}
				if (job == null) {
					break;
				}
				convertOne(job);
			}
		} finally {
			running = false;
			currentName = "";
			progress = 0;
		}
	}

	private static long clipStart(Path job) {
		if (!Files.isDirectory(job)) {
			return Long.MIN_VALUE;
		}
		try {
			for (String line : Files.readAllLines(job.resolve("clip.meta"))) {
				if (line.startsWith("startTsNs=")) {
					return Long.parseLong(line.substring("startTsNs=".length()).trim());
				}
			}
		} catch (Exception ignored) {
		}
		return Long.MIN_VALUE;
	}

	private static void convertOne(Path job) {
		currentName = job.getFileName().toString();
		progress = 0;
		String base = currentName.endsWith(".rawv")
			? currentName.substring(0, currentName.length() - ".rawv".length())
			: currentName;
		Path mp4 = job.resolveSibling(base + ".mp4");
		List<Path> segs = segments(job);
		long startTs = clipStart(job);

		FfmpegEncoder enc = null;
		boolean ok = false;
		String error = "";
		try {
			long total = 1;
			for (Path s : segs) {
				total += Files.size(s);
			}
			long readBytes = 0;
			long baseTs = Long.MIN_VALUE;
			long lastTs = 0;
			int w = 0;
			int h = 0;
			int fps = 0;
			int frameBytes = 0;
			boolean aborted = false;

			for (Path seg : segs) {
				if (aborted) {
					break;
				}
				try (DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(seg), 4 << 20))) {
					byte[] magic = in.readNBytes(RawWriter.MAGIC.length);
					if (!Arrays.equals(magic, RawWriter.MAGIC)) {
						throw new IOException("not a Record raw file: " + seg.getFileName());
					}
					int sw = in.readInt();
					int sh = in.readInt();
					int sfps = in.readInt();
					readBytes += RawWriter.HEADER_BYTES;
					if (enc == null) {
						w = sw;
						h = sh;
						fps = sfps;
						frameBytes = Yuv.i420Size(w, h);
						RecordPlan plan = new RecordPlan(w, h, fps,
							RecordPlan.pickEncoder(RecordConfig.get(), hw, FfmpegManager.encoders()),
							RecordConfig.Quality.HIGH, hw);
						enc = new FfmpegEncoder(FfmpegManager.command(), plan, mp4, true, true);
						enc.start();
					} else if (sw != w || sh != h || sfps != fps) {
						RecordMod.LOGGER.warn("[Record] Skipping segment {} (different size)", seg.getFileName());
						continue;
					}

					while (!aborted) {
						long ts;
						try {
							ts = in.readLong();
						} catch (EOFException eof) {
							break;
						}
						byte[] buf;
						while ((buf = enc.acquire()) == null) {
							if (enc.hasFailed()) {
								aborted = true;
								break;
							}
							Thread.sleep(3);
						}
						if (aborted) {
							break;
						}
						try {
							in.readFully(buf, 0, frameBytes);
						} catch (EOFException eof) {
							enc.release(buf);
							break;
						}
						readBytes += 8L + frameBytes;
						progress = (int) Math.min(99, readBytes * 100L / total);
						if (ts < startTs) {
							enc.release(buf);
							continue;
						}
						if (baseTs == Long.MIN_VALUE) {
							baseTs = ts; // the video starts at its first frame
						}
						lastTs = ts - baseTs;
						FrameSink.Frame frame = new FrameSink.Frame(buf, lastTs);
						while (!enc.offer(frame)) {
							if (enc.hasFailed()) {
								aborted = true;
								break;
							}
							Thread.sleep(2);
						}
					}
				}
			}
			if (enc == null) {
				throw new IOException("no recording data found");
			}
			enc.finish(lastTs + 1_000_000_000L / Math.max(1, fps));
			while (!enc.isDone()) {
				Thread.sleep(100);
			}
			ok = !enc.hasFailed() && enc.framesWritten() > 0;
			if (!ok) {
				error = enc.hasFailed() ? enc.failureMessage() : "the recording had no frames";
			}
		} catch (Exception e) {
			error = String.valueOf(e.getMessage());
			RecordMod.LOGGER.error("[Record] Conversion failed for {}", job, e);
		}

		if (ok) {
			if (RecordConfig.get().deleteRawAfterConvert) {
				deleteJob(job);
			}
			Recorder.INSTANCE.setStatus("Converted: " + mp4.getFileName(), false, 9000);
			RecordMod.LOGGER.info("[Record] Converted {} -> {}", job.getFileName(), mp4.getFileName());
		} else {
			Recorder.INSTANCE.setStatus("Conversion failed (" + currentName + "): " + error, true, 14000);
		}
	}

	private static void deleteJob(Path job) {
		try {
			if (Files.isDirectory(job)) {
				try (Stream<Path> walk = Files.walk(job)) {
					walk.sorted(Comparator.reverseOrder()).forEach(p -> {
						try {
							Files.deleteIfExists(p);
						} catch (IOException ignored) {
						}
					});
				}
			} else {
				Files.deleteIfExists(job);
			}
		} catch (IOException ignored) {
		}
	}
}
