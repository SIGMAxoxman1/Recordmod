package com.sigmaxox.record.client.ffmpeg;

import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.config.RecordConfig;
import com.sigmaxox.record.client.config.RecordConfig.Encoder;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Finds FFmpeg (config path, own download folder, PATH), downloads it on Windows if missing,
 * and tests which H.264 encoders really work on this machine (NVENC / AMF / QuickSync / x264).
 */
public final class FfmpegManager {
	private FfmpegManager() {
	}

	public enum State {
		UNKNOWN, SEARCHING, MISSING, DOWNLOADING, PROBING, READY, FAILED
	}

	private static final String[] DOWNLOAD_URLS = {
		"https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
		"https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
	};

	private static volatile State state = State.UNKNOWN;
	private static volatile String command;
	private static volatile Set<Encoder> encoders = Set.of();
	private static volatile int progress;
	private static volatile String error = "";
	private static boolean started;

	public static State state() {
		return state;
	}

	/** The executable to run, valid when state() == READY. */
	public static String command() {
		return command;
	}

	/** Encoders that passed the real test, valid when state() == READY. */
	public static Set<Encoder> encoders() {
		return encoders;
	}

	public static int progress() {
		return progress;
	}

	public static String error() {
		return error;
	}

	private static Path dir() {
		return FabricLoader.getInstance().getGameDir().resolve("record").resolve("ffmpeg");
	}

	private static boolean isWindows() {
		return System.getProperty("os.name", "").toLowerCase().contains("win");
	}

	/** Starts the background search + probe once (called when the game starts). */
	public static synchronized void init() {
		if (started) {
			return;
		}
		started = true;
		runAsync(FfmpegManager::searchAndProbe);
	}

	/** Downloads FFmpeg (Windows only) or explains what to do on other systems. */
	public static synchronized void downloadAsync() {
		if (state == State.DOWNLOADING || state == State.PROBING || state == State.SEARCHING) {
			return;
		}
		if (!isWindows()) {
			error = "Install FFmpeg and add it to PATH (or set ffmpegPath in config/record.json).";
			state = State.FAILED;
			return;
		}
		state = State.DOWNLOADING;
		progress = 0;
		runAsync(FfmpegManager::download);
	}

	private static void runAsync(Runnable r) {
		Thread t = new Thread(r, "Record-FFmpeg");
		t.setDaemon(true);
		t.start();
	}

	private static void searchAndProbe() {
		try {
			state = State.SEARCHING;
			String found = find();
			if (found == null) {
				state = State.MISSING;
				return;
			}
			probe(found);
		} catch (Throwable t) {
			RecordMod.LOGGER.warn("[Record] FFmpeg search failed", t);
			error = String.valueOf(t.getMessage());
			state = State.FAILED;
		}
	}

	private static String find() {
		String custom = RecordConfig.get().ffmpegPath;
		if (!custom.isBlank() && Files.isRegularFile(Path.of(custom))) {
			return custom;
		}
		Path own = dir().resolve(isWindows() ? "ffmpeg.exe" : "ffmpeg");
		if (Files.isRegularFile(own)) {
			return own.toAbsolutePath().toString();
		}
		if (runsOk("ffmpeg", "-version")) {
			return "ffmpeg";
		}
		return null;
	}

	private static boolean runsOk(String... cmd) {
		try {
			Process p = new ProcessBuilder(cmd).redirectErrorStream(true)
				.redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
			if (!p.waitFor(15, TimeUnit.SECONDS)) {
				p.destroyForcibly();
				return false;
			}
			return p.exitValue() == 0;
		} catch (Exception e) {
			return false;
		}
	}

	private static void probe(String cmd) {
		state = State.PROBING;
		Map<Encoder, String> names = new EnumMap<>(Encoder.class);
		names.put(Encoder.NVENC, "h264_nvenc");
		names.put(Encoder.AMF, "h264_amf");
		names.put(Encoder.QSV, "h264_qsv");
		names.put(Encoder.X264, "libx264");

		Set<Encoder> ok = EnumSet.noneOf(Encoder.class);
		for (Map.Entry<Encoder, String> e : names.entrySet()) {
			boolean works = runsOk(cmd, "-hide_banner", "-loglevel", "error",
				"-f", "lavfi", "-i", "color=c=black:s=256x256:r=5",
				"-frames:v", "1", "-an", "-c:v", e.getValue(), "-f", "null", "-");
			if (works) {
				ok.add(e.getKey());
			}
		}
		RecordMod.LOGGER.info("[Record] FFmpeg '{}' - working encoders: {}", cmd, ok);
		if (ok.isEmpty()) {
			error = "FFmpeg found but no H.264 encoder works.";
			state = State.FAILED;
			return;
		}
		command = cmd;
		encoders = ok;
		state = State.READY;
	}

	private static void download() {
		Exception last = null;
		for (String url : DOWNLOAD_URLS) {
			try {
				Files.createDirectories(dir());
				Path zip = dir().resolve("ffmpeg-download.zip");
				progress = 0;
				fetch(url, zip);
				extract(zip, dir().resolve("ffmpeg.exe"));
				Files.deleteIfExists(zip);
				String found = find();
				if (found == null) {
					throw new IOException("ffmpeg.exe not found after extraction");
				}
				probe(found);
				return;
			} catch (Exception e) {
				last = e;
				RecordMod.LOGGER.warn("[Record] FFmpeg download from {} failed", url, e);
			}
		}
		error = "FFmpeg download failed: " + (last == null ? "unknown" : last.getMessage());
		state = State.FAILED;
	}

	private static void fetch(String url, Path target) throws IOException, InterruptedException {
		HttpClient client = HttpClient.newBuilder()
			.followRedirects(HttpClient.Redirect.ALWAYS)
			.connectTimeout(Duration.ofSeconds(20))
			.build();
		HttpRequest request = HttpRequest.newBuilder(URI.create(url))
			.header("User-Agent", "record-mod")
			.GET()
			.build();
		HttpResponse<InputStream> response = client.send(request, HttpResponse.BodyHandlers.ofInputStream());
		if (response.statusCode() != 200) {
			throw new IOException("HTTP " + response.statusCode());
		}
		long total = response.headers().firstValueAsLong("Content-Length").orElse(-1L);
		try (InputStream in = response.body(); OutputStream out = Files.newOutputStream(target)) {
			byte[] buf = new byte[1 << 16];
			long done = 0;
			int n;
			while ((n = in.read(buf)) > 0) {
				out.write(buf, 0, n);
				done += n;
				if (total > 0) {
					progress = (int) (done * 100L / total);
				}
			}
		}
	}

	private static void extract(Path zip, Path exeTarget) throws IOException {
		try (ZipInputStream zin = new ZipInputStream(Files.newInputStream(zip))) {
			ZipEntry entry;
			while ((entry = zin.getNextEntry()) != null) {
				String name = entry.getName().replace('\\', '/');
				if (!entry.isDirectory() && name.endsWith("bin/ffmpeg.exe")) {
					try (OutputStream out = Files.newOutputStream(exeTarget)) {
						zin.transferTo(out);
					}
					return;
				}
			}
		}
		throw new IOException("bin/ffmpeg.exe not found inside the downloaded archive");
	}
}
