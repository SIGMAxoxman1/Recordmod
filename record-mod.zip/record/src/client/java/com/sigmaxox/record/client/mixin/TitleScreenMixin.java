package com.sigmaxox.record.client.mixin;

import com.sigmaxox.record.client.ui.RecordUi;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds "Record Now" + a settings button to the main menu (top-left corner). */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
	protected TitleScreenMixin(Component title) {
		super(title);
	}

	@Inject(method = "init()V", at = @At("TAIL"))
	private void record$addButtons(CallbackInfo ci) {
		this.addRenderableWidget(RecordUi.recordButton(8, 8, 110));
		this.addRenderableWidget(RecordUi.settingsButton(122, 8, this));
	}
}
