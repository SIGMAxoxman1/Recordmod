package com.sigmaxox.record.client.mixin;

import com.sigmaxox.record.client.export.ExportJob;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** The "Export last recording" button on the main menu (top-left corner). */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
	protected TitleScreenMixin(Component title) {
		super(title);
	}

	@Inject(method = "init()V", at = @At("TAIL"))
	private void record$addExportButton(CallbackInfo ci) {
		this.addRenderableWidget(Button.builder(Component.literal(ExportJob.label()), b -> {
			ExportJob.start(Minecraft.getInstance());
			b.setMessage(Component.literal(ExportJob.label()));
		}).bounds(8, 8, 150, 20).build());
	}
}
