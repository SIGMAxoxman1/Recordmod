package com.sigmaxox.record.client.mixin;

import com.sigmaxox.record.RecordMod;
import com.sigmaxox.record.client.ui.RecIndicator;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.state.gui.GuiRenderState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Draws the REC indicator and status messages on top of everything else. */
@Mixin(Gui.class)
public abstract class GuiMixin {
	@Shadow
	@Final
	private Minecraft minecraft;

	@Shadow
	@Final
	private GuiRenderState guiRenderState;

	@Unique
	private static boolean record$warned;

	@Inject(method = "extractRenderState(Lnet/minecraft/client/DeltaTracker;ZZ)V", at = @At("TAIL"))
	private void record$overlay(DeltaTracker deltaTracker, boolean shouldRenderLevel, boolean resourcesLoaded, CallbackInfo ci) {
		if (!resourcesLoaded) {
			return;
		}
		try {
			GuiGraphicsExtractor graphics = new GuiGraphicsExtractor(this.minecraft, this.guiRenderState, 0, 0);
			RecIndicator.draw(graphics, this.minecraft);
		} catch (Throwable t) {
			if (!record$warned) {
				record$warned = true;
				RecordMod.LOGGER.warn("[Record] Could not draw the REC indicator", t);
			}
		}
	}
}
