package com.sigmaxox.record.client.mixin;

import com.sigmaxox.record.client.ui.RecordUi;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds "Record Now" + a settings button to the pause menu (top-left corner). */
@Mixin(PauseScreen.class)
public abstract class PauseScreenMixin extends Screen {
	protected PauseScreenMixin(Component title) {
		super(title);
	}

	@Inject(method = "init()V", at = @At("TAIL"))
	private void record$addButtons(CallbackInfo ci) {
		this.addRenderableWidget(RecordUi.recordButton(8, 8, 110));
		this.addRenderableWidget(RecordUi.settingsButton(122, 8, this));
		if (com.sigmaxox.record.client.config.RecordConfig.get().mode == com.sigmaxox.record.client.config.RecordConfig.Mode.REPLAY) {
			this.addRenderableWidget(RecordUi.clipButton(146, 8, 70));
		}
	}
}
