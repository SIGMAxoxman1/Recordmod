package com.sigmaxox.record.client.hw;

import com.mojang.blaze3d.systems.DeviceInfo;
import com.mojang.blaze3d.systems.DeviceType;
import com.mojang.blaze3d.systems.RenderSystem;
import java.lang.management.ManagementFactory;
import net.minecraft.client.Minecraft;

/** Reads the machine's capabilities once per call (cheap) and rates it weak / medium / strong. */
public final class HardwareDetect {
	private HardwareDetect() {
	}

	public enum Tier {
		WEAK("Weak"), MEDIUM("Medium"), STRONG("Strong");

		public final String label;

		Tier(String label) {
			this.label = label;
		}
	}

	public record Info(String gpuName, String gpuVendor, String backend, DeviceType gpuType,
					   int cpuCores, long ramMb, int refreshHz, Tier tier) {
	}

	/** Must be called on the render thread. */
	public static Info detect(Minecraft mc) {
		String gpuName = "Unknown GPU";
		String vendor = "";
		String backend = "OpenGL";
		DeviceType type = DeviceType.OTHER;
		try {
			DeviceInfo info = RenderSystem.getDevice().getDeviceInfo();
			gpuName = info.name();
			vendor = info.vendorName();
			backend = info.backendName();
			type = info.type();
		} catch (Throwable ignored) {
		}

		int cores = Math.max(1, Runtime.getRuntime().availableProcessors());
		long ramMb = 0;
		try {
			var os = (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
			ramMb = os.getTotalMemorySize() / (1024L * 1024L);
		} catch (Throwable ignored) {
		}

		int refresh = 60;
		try {
			int r = mc.getWindow().getRefreshRate();
			if (r >= 24) {
				refresh = r;
			}
		} catch (Throwable ignored) {
		}

		int score = 0;
		if (type == DeviceType.DISCRETE) {
			score += 3;
		} else if (type == DeviceType.INTEGRATED) {
			score += 1;
		}
		if (cores >= 12) score += 3;
		else if (cores >= 8) score += 2;
		else if (cores >= 6) score += 1;
		else if (cores <= 4) score -= 1;
		if (ramMb >= 15000) score += 1;
		else if (ramMb > 0 && ramMb <= 8200) score -= 1;

		Tier tier = score >= 5 ? Tier.STRONG : score >= 2 ? Tier.MEDIUM : Tier.WEAK;
		return new Info(gpuName, vendor, backend, type, cores, ramMb, refresh, tier);
	}
}
