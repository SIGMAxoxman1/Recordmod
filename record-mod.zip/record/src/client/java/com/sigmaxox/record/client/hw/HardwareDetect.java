package com.sigmaxox.record.client.hw;

import com.mojang.blaze3d.systems.DeviceInfo;
import com.mojang.blaze3d.systems.DeviceType;
import com.mojang.blaze3d.systems.RenderSystem;
import java.lang.management.ManagementFactory;
import java.util.regex.Pattern;
import net.minecraft.client.Minecraft;

/** Reads the machine's capabilities once per call (cheap) and rates it weak / medium / strong. */
public final class HardwareDetect {
	private HardwareDetect() {
	}

	/** Entry-level GPUs that struggle to run the game and record at the same time. */
	private static final Pattern LOW_END_GPU = Pattern.compile(
		"(\\bMX\\s?\\d{3}|\\bT[1-6]\\d{2}\\b|\\bGT\\s?\\d{3}|GTX\\s?10[3-5]0|Quadro\\s+[KMP]\\d|\\bVega\\b"
			+ "|Radeon(\\(TM\\))?\\s+Graphics|\\bRX\\s?5\\d{2}\\b|\\bR[2-9]\\s)", Pattern.CASE_INSENSITIVE);
	/** Low-mid GPUs: never rated above MEDIUM. */
	private static final Pattern ENTRY_GPU = Pattern.compile(
		"(GTX\\s?(16[3-5]0|960|970|1060)|RTX\\s?(20|30|40|50)50)", Pattern.CASE_INSENSITIVE);

	public enum Tier {
		WEAK("Weak"), MEDIUM("Medium"), STRONG("Strong");

		public final String label;

		Tier(String label) {
			this.label = label;
		}
	}

	public record Info(String gpuName, String gpuVendor, String backend, DeviceType gpuType,
					   int cpuCores, long ramMb, int refreshHz, Tier tier) {
	}

	/** Must be called on the render thread. */
	public static Info detect(Minecraft mc) {
		String gpuName = "Unknown GPU";
		String vendor = "";
		String backend = "OpenGL";
		DeviceType type = DeviceType.OTHER;
		try {
			DeviceInfo info = RenderSystem.getDevice().getDeviceInfo();
			gpuName = info.name();
			vendor = info.vendorName();
			backend = info.backendName();
			type = info.type();
		} catch (Throwable ignored) {
		}

		int cores = Math.max(1, Runtime.getRuntime().availableProcessors());
		long ramMb = 0;
		try {
			var os = (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
			ramMb = os.getTotalMemorySize() / (1024L * 1024L);
		} catch (Throwable ignored) {
		}

		int refresh = 60;
		try {
			int r = mc.getWindow().getRefreshRate();
			if (r >= 24) {
				refresh = r;
			}
		} catch (Throwable ignored) {
		}

		int score = 0;
		if (type == DeviceType.DISCRETE) {
			score += 3;
		} else if (type == DeviceType.INTEGRATED) {
			score += 1;
		}
		if (cores >= 12) score += 3;
		else if (cores >= 8) score += 2;
		else if (cores >= 6) score += 1;
		else if (cores <= 4) score -= 1;
		if (ramMb >= 15000) score += 1;
		else if (ramMb > 0 && ramMb <= 8200) score -= 1;

		Tier tier = score >= 5 ? Tier.STRONG : score >= 2 ? Tier.MEDIUM : Tier.WEAK;
		String gpuText = gpuName + " " + vendor;
		if (LOW_END_GPU.matcher(gpuText).find()) {
			tier = Tier.WEAK;
		} else if (ENTRY_GPU.matcher(gpuText).find() && tier == Tier.STRONG) {
			tier = Tier.MEDIUM;
		}
		return new Info(gpuName, vendor, backend, type, cores, ramMb, refresh, tier);
	}
}
